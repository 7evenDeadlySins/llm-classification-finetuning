# 02. 数据工程、多源合并与分布对齐（Data Engineering & Distribution Alignment）

[返回主说明](../README.md) · [上一篇：问题与挑战](01_problem_and_challenges.md) · [下一篇：模型架构与训练策略](03_model_architecture_and_training.md)

---

## 1. 不可变基准：分组分层与 Token 均衡划分

为确保所有数据配比与超参数实验能够在同一套绝对公平、零数据泄漏的基准上评测，本项目首先对 **57,477 行** Kaggle 竞赛基准数据执行确定性划分，并**永久冻结了 11,495 条验证集 ID（`validation_ids.csv`）**。

### 1.1 预处理流水线与防泄漏规范

1. **同回复纠偏（划分前执行）**：在推导三分类标签前，按原始字段逐字符精确比对 `response_a == response_b`（不修剪空白、不忽略大小写）。共发现并修正了 **27 条**两侧回复完全一致却被原始标为一方胜出的噪声对局（其中后续划入训练集的 22 条含 10 条原标 A 胜、12 条原标 B 胜；划入验证集的 5 条含 2 条原标 A 胜、3 条原标 B 胜），将其统一校正为 `label = 2`（`winner_tie = 1`）。
2. **完整 Prompt 分组隔离（`group_id`）**：基于规范化后的 Prompt JSON 字符串（`sort_keys=True, separators=(",", ":")`）计算 SHA-256 哈希作为 `group_id`。57,477 条对局共归并为 **51,734 个**互不重叠的 Prompt 组。划分逻辑强制要求**同一 `group_id` 下的所有对局整体进入训练集或整体进入验证集**，彻底阻断相似上下文跨分区泄漏。
3. **Token 均衡整数交换优化**：由于对话长度直接影响验证集分布与推理耗时，仅保证行数 80/20 分层（`seed = 42`）仍可能造成长短分布偏差。算法采用与训练完全一致的 `Skywork/Skywork-Reward-V2-Qwen3-4B` 分词器（锁定 revision `fd958fef475f323f4e6b195930e3dd918485c668`）及 `sr2-qwen3-chat-template-v1` 序列化协议统计每条对局的精确 `A+B` Token 数；在严格保持各类别计数与行数配额完全不变的前提下，对具有相同三分类向量 `(count_A, count_B, count_Tie)` 的整组 Prompt 执行最多 `1,000` 次贪心互换，经 **9 次整组互换**即达成均衡：验证集行相对偏差 **0.00348%**，Token 相对偏差 **0.4774%**（均严格满足 `< 0.5%` 硬阈值）。
4. **单向紧凑存储（`is_swapped=False`）**：依托分类头的代数级置换等变设计，数据表始终仅保留每个样本 ID 的唯一原始 A/B 方向（`is_swapped=False`），加载器在运行时强校验唯一原始 ID、合法标签及零跨分区 `group_id` 重叠。

---

## 2. 多源纯 Arena 接入与硬投票合并流水线

围绕挑战四提出的数据扩展需求，项目通过 `MergeExternalDataPipeline`（入口 `data/merge_external_data.py`）接入并清洗了三组与竞赛同样来源于真实人类 Arena 盲测的公开偏好数据集，全部源 Parquet 文件均锁定 Hugging Face Git Commit 与官方 LFS SHA-256 校验码（记录于 `data/raw/external/sources.json`）：

| 数据源 | 锁定 Hugging Face Revision | 原始样本量 | 合并池保留行数 | 多轮占比 | 平均分支 Tokens | 英语（`en`）保留占比 | 与 Kaggle 64 模型名交集 |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: | :---: |
| **Kaggle 基准集** | 竞赛 `train.csv` | 57,477 | 45,982（训练）+ 11,495（验证） | 13.00%（训）/ 13.60%（验） | 390（训）/ 392（验） | 未独立标注 | 64 个模型（基准） |
| **`lmsys/chatbot_arena_conversations`** | `1b6335d42a1d2c7e34870c905d03ab964f7f2bd8` | 33,000 | 24,227 | 12.25% | 266 | 84.36% | **76.70% 出现频次** |
| **`lmarena-ai/arena-human-preference-140k`** | `6322995ab34d7c2693e3f47dd13fa5caa0789a74` | 135,634 | 135,440 | 31.71% | 1,639 | 52.48% | **0.00%**（53 个新模型） |
| **`lmarena-ai/arena-expert-5k`** | `171f77047d8d153c41b3f2c11bc910273f62f183` | 5,128 | 3,348 | 35.72% | 3,811 | 56.54% | **0.00%**（103 个新模型） |

### 2.1 六项严谨清洗、历史回填与硬投票规范

1. **受限容器解析与多模态整条排除**：针对 `arena-expert-5k` 中以 NumPy `array(..., dtype=object)` 形式存储的对话文本编写纯词法受限解析器（不执行任意表达式）；凡任一分支含图片、音频等非文本内容（排除 `1` 条），或角色序列不能严格匹配交替的 `user`/`assistant` 结构（排除 `12` 条），均整条丢弃而不做破坏性修剪。
2. **后续评估历史精确对齐（`evaluation_order > 1`）**：`arena-human-preference-140k`（占比 `20.12%`）与 `arena-expert-5k`（占比 `23.98%`）中存在同一会话多次重抽模型的后续评估投票。转换器依据 `full_conversation`（分别匹配 `model_side_a/b` 与 `model_a/b` 键名）精确定位并还原当前评估之前的完整多轮对话历史，保留当次评估的真实人类标签。
3. **冻结验证集绝对隔离**：计算每条外部样本的完整规范化 `group_id`，凡与 **11,495 条**冻结 Kaggle 验证集任意 Prompt 哈希重合的记录全部排除（共隔离 `2,348` 条外部输入），确保验证指标绝对纯净。
4. **对局级去重与硬投票仲裁（`ExternalBattleDeduplicator`）**：去重键定义为**完整 Prompt 上下文 + 无序 A/B 回答对**（可自动识别 A/B 互换的重复对局），同时保留训练集中同 Prompt 下的不同模型回答对。与 Kaggle 训练集重复的外部样本无条件让位于 Kaggle（剔除 `6,445` 条）；内部及跨源重复投票则统一至规范 A/B 方向并按 `vote_id` 去除重复票副本（剔除 `1,753` 条），汇总各独立投票（`merged_vote` 涉及 `51` 条）后采用**唯一多数票硬标签**——若最高票并列（共 `17` 组对局 / `34` 条记录）则整组舍弃，防止争议对局被误判为平局。
5. **模型上下文零截断边界筛选**：基于固定 SR2 分词器与 `sr2-qwen3-chat-template-v1` 统计全部候选对局的完整分支长度，凡任一完整分支超出 `Skywork-Reward-V2-Qwen3-4B` 位置编码上限 `max_position_embeddings = 40,960` 的对局整条移入 `excluded_model_context.parquet` 单独留存（共剔除 `102` 组对局 / `103` 条记录），**全量保留样本最大单分支为 `40,953` tokens**，绝不截断文本。
6. **空回复与平局映射**：将 `tie`、`both_bad` 与 `tie (bothbad)` 统一映射为 `label = 2`；双侧末轮均空或完整回复一致时修正为平局；单侧空回复保留原始人类投票标签。

经过上述 6 步流水线与回读完整性检验，共构建出 **220,492 行**纯 Arena 真实偏好合并池（`data/processed/external_merged/`：训练集 `208,997` 行，冻结验证集 `11,495` 行，重构 SHA-256 `9c1f041dc3cdfc63a8a924b9433d124da4905d93d5e40e4e03bcc03eeb993bc6`）。

---

## 3. 分布对齐动机与两套对比训练集构造

拥有 **220,492 行**高质量纯 Arena 候选池后，直接将其全量（`208,997` 行训练）投入模型训练会面临两大显著的结构性失衡问题：
1. **Token 体量与风格压倒性失真**：合并池训练集中仅 Arena Human 就占了 `135,440` 行（A+B 共 **443,906,527 tokens**），而 Kaggle 训练集仅 `45,982` 行（**35,856,134 tokens**）。直接全量混合会让模型在样本与长度加权层面上绝大多数时间都在学习 2025 年多语言长文风格，大幅稀释 Kaggle 竞赛原始特征。
2. **平局先验比例下滑**：全量纯 Arena 合并池的训练集天然平局率为 `59,610 / 208,997 = 28.5219%`，明显低于 Kaggle 基准的 `30.9480%`，易造成验证集平局预测系统性欠校准。

为此，团队设计并对比了**两套严格对齐竞赛 `30.95%` 平局占比、且体量可控的纯净训练数据方案**，并通过 `results/` 中的受控实验系统验证二者特性：

```mermaid
flowchart TD
    Pool["220,492 行纯 Arena 真实合并池\nKaggle 57,477 + LMSYS 24,227 + Arena Human 135,440 + Arena Expert 3,348"]
    Pool --> BranchA["方案 A: lmsys33k (67,045 训练 / 78,540 全量)\nKaggle 45,982 + 同世代 LMSYS 20,050\n+ 英文稀有度前 rank 的 1,013 条真实 Arena 平局"]
    Pool --> BranchB["方案 B: external_merged 稀有度精选 (52,640 训练 / 66,411 全量)\n基于 external_english_rarity_rank.csv (74,474 英文候选)\n按 Kaggle 等 Token 预算与 30.95% 平局比例动态选入"]
```

---

## 4. 两套受控验证数据集的精确统计

### 4.1 方案 A：`lmsys33k`（同世代分布增强集）

在 `45,982` 条 Kaggle 训练样本与模型世代重合度高达 `76.70%` 的 **20,050 条**早期 LMSYS 33K 样本（多轮 `2,910` 条、`14.51%`，均值 `272.19` tokens/分支）基础上，两者合集在训练集范围的平局占比为 `29.8885%`。为在零副作用的前提下锚定竞赛 `30.9480%` 的真实平局先验，从英文稀有度排序表 `external_english_rarity_rank.csv` 中按 `rank` 升序（截止 `rank = 3,710`）精选加入了 **1,013 条高质量真实英文 Arena 平局**（`948` 条 `arena_human` + `65` 条 `arena_expert`，最高单分支 `35,130` tokens）：

| 作用域 | 总行数 | Kaggle 行数 | LMSYS 行数 | 精选 Arena 平局行数 | 总平局数 (占比) | A+B 总 Tokens | 最大单分支 |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| **留出验证训练** | **67,045** | 45,982 | 20,050 | 1,013 (948 human + 65 expert) | 20,749 (**30.9479%**) | 53,593,296 | 35,130 |
| **全量构建 (`--build`)** | **78,540** | 57,477 | 20,050 | 1,013 (948 human + 65 expert) | 24,307 (**30.9486%**) | 62,610,889 | 35,130 |

### 4.2 方案 B：`external_merged` + 英文稀有度预算筛选（`RankedExternalSelector`）

针对 220,492 行真实合并池，项目预先构建了收录 **74,474 条全英文高质量外部候选**的排序表 `external_english_rarity_rank.csv`（来源分布：`arena_human` **57,543**、`lmsys` **15,513**、`arena_expert` **1,418**；按双分支词汇稀有度总分 `total_score = score_a + score_b` 降序赋予唯一正整数 `rank`）。训练加载时，`RankedExternalSelector` 执行如下确定性等预算挑选：
1. 计算当前作用域 Kaggle 训练数据的 `A+B` 总 Token 数作为外部预算目标 $B_{\text{tok}}$，以及 Kaggle 实际平局率 $p_{\text{tie}}$；
2. 对任意外部选入规模 $n$，严格锁定平局数量为 $\operatorname{round}(n \cdot p_{\text{tie}})$（采用精确四舍五入 `(n * kaggle_ties + kaggle_rows // 2) // kaggle_rows`），分别从排序表的平局子序列与非平局子序列按 `rank` 升序取前若干条；
3. 选出使外部样本总 Token 数最接近 $B_{\text{tok}}$ 的最优 $n$（偏差相等取较小 $n$）。

通过这一机制，模型以与 Kaggle 训练集几乎 `1:1` 的 Token 体量获得了丰富、去重、无多语言漂移的现代 Arena 对局补充：

| 作用域 | Kaggle 行数 (A+B Tokens) | 入选外部行数 (A+B Tokens) | 入选外部来源分解 (总 / 平局) | 总训练行数 | 总平局数 (占比) | 入选最大单分支 |
| :--- | :---: | :---: | :--- | ---: | ---: | ---: |
| **留出验证训练** | 45,982 (35,856,134) | **6,658** (35,865,470) | Arena Human 5,908 (1,809)<br>Arena Expert 379 (112)<br>LMSYS 371 (139) | **52,640** | 16,290 (**30.9460%**) | **40,384** |
| **全量构建 (`--build`)** | 57,477 (44,873,727) | **8,934** (44,865,610) | Arena Human 8,018 (2,464)<br>LMSYS 471 (166)<br>Arena Expert 445 (135) | **66,411** | 20,553 (**30.9482%**) | **40,384** |

---

## 5. 会话序列化协议（`sr2-qwen3-chat-template-v1`）

两套数据集与冻结验证集在输入模型前均通过 `ConversationSerializer` 执行完全一致的双分支独立序列化：
- A 支路与 B 支路分别独立组织为交替的 `{"role": "user", "content": ...}` 与 `{"role": "assistant", "content": ...}` 消息列表（若某轮助手回答为 `null` 则渲染为空字符串并保留轮次占位）；
- 不添加任何自定义 `system` 消息或工具定义，调用 `tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=False, continue_final_message=False)`；
- 原样保留官方 `chat_template.jinja` 在最后一轮助手回复前注入的默认推理标记 `<think>\n\n</think>\n\n` 与末尾换行符；
- 使用锁定版本的分词器按 `add_special_tokens=False`、`truncation=False`、`padding=False` 完成编码，并强校验所有分支非空且长度严格不超过模型 `max_length`（`lmsys33k` 预设为 `35,130`，`external_merged` 预设为 `40,960`）。
