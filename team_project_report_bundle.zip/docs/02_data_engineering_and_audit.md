# 02. Data Engineering, Multi-Source Merging & Distribution Alignment

[Back to Main Guide](../README.md) · [Previous: Problem & Challenges](01_problem_and_challenges.md) · [Next: Model Architecture & Training](03_model_architecture_and_training.md)

---

## 1. Immutable Benchmark: Group-Stratified and Token-Balanced Split

To evaluate all data mixtures and hyperparameters on a fair, leakage-free benchmark, we first apply a deterministic split to the **57,477-row** Kaggle competition dataset and **permanently freeze 11,495 validation IDs (`validation_ids.csv`)**.

### 1.1 Preprocessing Pipeline and Anti-Leakage Protocol

1. **Identical-response correction (pre-split)**: Before deriving three-class labels, `response_a == response_b` is compared character-by-character on raw fields (preserving whitespace and case). This identifies and corrects **27** noisy battles where identical responses were labeled as a win for one side (22 later assigned to train: 10 A-wins, 12 B-wins; 5 assigned to validation: 2 A-wins, 3 B-wins), reassigning all 27 to `label = 2` (`winner_tie = 1`).
2. **Full-prompt group isolation (`group_id`)**: A SHA-256 hash of the canonicalized prompt JSON string (`sort_keys=True, separators=(",", ":")`) defines `group_id`. The 57,477 battles consolidate into **51,734** non-overlapping prompt groups. The splitter enforces that **all battles sharing a `group_id` enter either train or validation together**, preventing cross-split context leakage.
3. **Token-balanced integer swap optimization**: Because dialogue length affects both validation distribution and inference latency, an 80/20 row-stratified split (`seed = 42`) alone can leave token-count imbalances. Using the exact training tokenizer (`Skywork/Skywork-Reward-V2-Qwen3-4B`, locked revision `fd958fef475f323f4e6b195930e3dd918485c668`) and `sr2-qwen3-chat-template-v1`, we compute exact `A+B` token counts per battle. Keeping class counts and row quotas strictly invariant, a greedy swapper exchanges whole prompt groups with identical `(count_A, count_B, count_Tie)` vectors for up to `1,000` iterations. After **9 group swaps**, the split achieves a validation row relative deviation of **0.00348%** and a token relative deviation of **0.4774%** (both strictly `< 0.5%`).
4. **Single-direction compact storage (`is_swapped=False`)**: Relying on the head's algebraic swap equivariance, tables store only the canonical A/B orientation (`is_swapped=False`). At runtime, the loader enforces unique original IDs, valid labels, and zero `group_id` overlap across splits.

---

## 2. Multi-Source Pure-Arena Ingestion and Hard-Vote Merging

To address Challenge 4, `MergeExternalDataPipeline` (`data/merge_external_data.py`) ingests and cleans three public preference datasets sourced from blind human Arena evaluations. All source Parquet files are pinned to Hugging Face Git commits and official LFS SHA-256 checksums (recorded in `data/raw/external/sources.json`):

| Data Source | Pinned Hugging Face Revision | Raw Rows | Retained Rows | Multi-Turn Share | Mean Branch Tokens | English (`en`) Share | Overlap with 64 Kaggle Models |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: | :---: |
| **Kaggle Benchmark** | Competition `train.csv` | 57,477 | 45,982 (Train) + 11,495 (Val) | 13.00% (Tr) / 13.60% (Val) | 390 (Tr) / 392 (Val) | Not separately tagged | 64 models (baseline) |
| **`lmsys/chatbot_arena_conversations`** | `1b6335d42a1d2c7e34870c905d03ab964f7f2bd8` | 33,000 | 24,227 | 12.25% | 266 | 84.36% | **76.70% occurrence share** |
| **`lmarena-ai/arena-human-preference-140k`** | `6322995ab34d7c2693e3f47dd13fa5caa0789a74` | 135,634 | 135,440 | 31.71% | 1,639 | 52.48% | **0.00%** (53 new models) |
| **`lmarena-ai/arena-expert-5k`** | `171f77047d8d153c41b3f2c11bc910273f62f183` | 5,128 | 3,348 | 35.72% | 3,811 | 56.54% | **0.00%** (103 new models) |

### 2.1 Six Cleaning, History Reconstruction, and Hard-Vote Rules

1. **Restricted container parsing and multimodal exclusion**: For `arena-expert-5k`, where conversations are serialized as NumPy `array(..., dtype=object)` strings, a purely lexical restricted parser avoids arbitrary code execution. Any battle containing non-text modalities such as images or audio (`1` row excluded) or failing strict alternating `user`/`assistant` role structure (`12` rows excluded) is dropped whole without destructive trimming.
2. **Exact alignment of subsequent evaluations (`evaluation_order > 1`)**: Both `arena-human-preference-140k` (`20.12%`) and `arena-expert-5k` (`23.98%`) contain follow-up evaluations within the same session. The converter locates and reconstructs the full multi-turn conversation history preceding the current evaluation from `full_conversation` (matching `model_side_a/b` and `model_a/b` keys, respectively) while preserving that round's human label.
3. **Strict isolation of the frozen validation set**: Canonical `group_id` hashes are computed for every external sample; any record matching any prompt in the **11,495-row** frozen Kaggle validation set is removed (`2,348` external rows excluded), ensuring zero validation contamination.
4. **Battle-level deduplication and hard-vote arbitration (`ExternalBattleDeduplicator`)**: The deduplication key is defined as **full prompt context + unordered A/B response pair** (catching A/B-swapped duplicates while retaining distinct model pairs on the same prompt). External records duplicating Kaggle Train defer unconditionally to Kaggle (`6,445` rows removed). Internal and cross-source duplicates are canonicalized to a single A/B direction, deduplicated by `vote_id` (`1,753` duplicate ballots removed), and aggregated across independent ballots (`51` rows involved in `merged_vote`) using a **strict majority hard label**—any tied plurality (`17` battle groups / `34` rows) is discarded entirely to avoid mislabeling contested battles as ties.
5. **Zero-truncation context-limit filtering**: Full branch lengths are measured with the pinned SR2 tokenizer and `sr2-qwen3-chat-template-v1`. Any battle with a branch exceeding `Skywork-Reward-V2-Qwen3-4B`'s `max_position_embeddings = 40,960` is moved to `excluded_model_context.parquet` (`102` battle groups / `103` rows excluded). **The longest retained single branch is `40,953` tokens**, with zero text truncation.
6. **Empty-response and tie mapping**: `tie`, `both_bad`, and `tie (bothbad)` map to `label = 2`. Battles where both final responses are empty or full responses are identical are corrected to ties; single-side empty responses retain their original human vote.

After these six steps and round-trip integrity verification, the pipeline produces a **220,492-row** pure-Arena human preference pool (`data/processed/external_merged/`: `208,997` training rows and `11,495` frozen validation rows; reconstructed SHA-256 `9c1f041dc3cdfc63a8a924b9433d124da4905d93d5e40e4e03bcc03eeb993bc6`).

---

## 3. Distribution Alignment Motivation and Two Comparative Training Sets

Feeding all `208,997` training rows of the **220,492-row** pool directly into training introduces two severe structural imbalances:
1. **Token-volume and stylistic swamping**: Arena Human alone contributes `135,440` rows (**443,906,527 A+B tokens**), compared to `45,982` rows (**35,856,134 tokens**) in Kaggle Train. Full mixing causes training to be dominated by 2025 multilingual long-form responses, diluting competition-specific features.
2. **Tie-prior drift**: The unfiltered merged training pool has a natural tie rate of `59,610 / 208,997 = 28.5219%`, notably below Kaggle's `30.9480%`, which systematically under-calibrates tie predictions.

Accordingly, we design and compare **two clean training sets strictly aligned to the `30.95%` tie rate with controlled volume**, systematically evaluated via controlled experiments in `results/`:

```mermaid
flowchart TD
    Pool["220,492-Row Pure-Arena Merged Pool\nKaggle 57,477 + LMSYS 24,227 + Arena Human 135,440 + Arena Expert 3,348"]
    Pool --> BranchA["Option A: lmsys33k (67,045 Train / 78,540 Full)\nKaggle 45,982 + Epoch-Matched LMSYS 20,050\n+ 1,013 Top-Ranked English Arena Ties"]
    Pool --> BranchB["Option B: external_merged Rarity Selection (52,640 Train / 66,411 Full)\nFrom external_english_rarity_rank.csv (74,474 EN candidates)\nDynamically selected by Kaggle token budget & 30.95% tie ratio"]
```

---

## 4. Exact Statistics of the Two Controlled Validation Datasets

### 4.1 Option A: `lmsys33k` (Epoch-Matched Distribution Augmentation)

Combining `45,982` Kaggle Train rows with **20,050** early LMSYS 33K rows (`76.70%` model-generation overlap with Kaggle; `2,910` multi-turn rows at `14.51%`, averaging `272.19` tokens/branch) yields a base tie rate of `29.8885%`. To anchor the true `30.9480%` competition tie prior without side effects, we select **1,013 high-quality English Arena ties** (`948` `arena_human` + `65` `arena_expert`, max branch `35,130` tokens) in ascending `rank` order (up to `rank = 3,710`) from `external_english_rarity_rank.csv`:

| Scope | Total Rows | Kaggle Rows | LMSYS Rows | Selected Arena Ties | Total Ties (Share) | Total A+B Tokens | Max Branch |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| **Holdout Train** | **67,045** | 45,982 | 20,050 | 1,013 (948 human + 65 expert) | 20,749 (**30.9479%**) | 53,593,296 | 35,130 |
| **Full Build (`--build`)** | **78,540** | 57,477 | 20,050 | 1,013 (948 human + 65 expert) | 24,307 (**30.9486%**) | 62,610,889 | 35,130 |

### 4.2 Option B: `external_merged` + English Rarity-Budgeted Selection (`RankedExternalSelector`)

From the 220,492-row merged pool, we pre-build `external_english_rarity_rank.csv` containing **74,474 all-English external candidates** (`57,543` `arena_human`, `15,513` `lmsys`, `1,418` `arena_expert`), ranked in descending order of dual-branch lexical rarity `total_score = score_a + score_b`. At load time, `RankedExternalSelector` performs deterministic token-budgeted selection:
1. Compute the `A+B` token sum of the active Kaggle training scope as the external token budget $B_{\text{tok}}$ and the empirical Kaggle tie rate $p_{\text{tie}}$;
2. For any candidate count $n$, fix the tie count to $\operatorname{round}(n \cdot p_{\text{tie}})$ (via integer rounding `(n * kaggle_ties + kaggle_rows // 2) // kaggle_rows`) and take the top-ranked tie and non-tie rows in ascending `rank` order;
3. Choose the $n$ whose external token sum is closest to $B_{\text{tok}}$ (breaking ties in favor of smaller $n$).

This provides deduplicated, English-only modern Arena battles at a `~1:1` token ratio with Kaggle Train:

| Scope | Kaggle Rows (A+B Tokens) | Selected External Rows (A+B Tokens) | External Breakdown (Total / Ties) | Total Train Rows | Total Ties (Share) | Max Selected Branch |
| :--- | :---: | :---: | :--- | ---: | ---: | ---: |
| **Holdout Train** | 45,982 (35,856,134) | **6,658** (35,865,470) | Arena Human 5,908 (1,809)<br>Arena Expert 379 (112)<br>LMSYS 371 (139) | **52,640** | 16,290 (**30.9460%**) | **40,384** |
| **Full Build (`--build`)** | 57,477 (44,873,727) | **8,934** (44,865,610) | Arena Human 8,018 (2,464)<br>LMSYS 471 (166)<br>Arena Expert 445 (135) | **66,411** | 20,553 (**30.9482%**) | **40,384** |

---

## 5. Conversation Serialization Protocol (`sr2-qwen3-chat-template-v1`)

Both training datasets and the frozen validation set undergo identical independent dual-branch serialization via `ConversationSerializer`:
- Branch A and Branch B are each formatted as alternating `{"role": "user", "content": ...}` and `{"role": "assistant", "content": ...}` messages (any `null` assistant turn is rendered as an empty string to preserve turn alignment);
- Without adding custom `system` messages or tool definitions, `tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=False, continue_final_message=False)` is called;
- The official `chat_template.jinja` default reasoning block `<think>\n\n</think>\n\n` before the final assistant turn and trailing newline are preserved verbatim;
- Tokenization uses the pinned tokenizer with `add_special_tokens=False`, `truncation=False`, and `padding=False`, asserting that every branch is non-empty and within the model's `max_length` (`35,130` for `lmsys33k`, `40,960` for `external_merged`).
