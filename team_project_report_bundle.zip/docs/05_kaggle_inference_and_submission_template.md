# 05. Kaggle 离线推理方案与测试结果后补模板（Submission & Pending Results）

[返回主说明](../README.md) · [上一篇：实验设计与结果分析](04_experiments_and_analysis.md) · [下一篇：论文撰写映射与总结](06_latex_writing_guide_and_conclusion.md)

---

## 1. 全量模型导出（`--build`）与交付物链路

在通过留出验证确定最优配置后，可通过全量构建模式（`uv run model SR2-Qwen3-4B --config <CONFIG> --build` 冻结头构建，或 `uv run model SR2-Qwen3-4B-lora --config <CONFIG> --build` LoRA 联合全量构建）使用**全量原始训练与验证行**（例如 `external_merged` 精选共 `66,411` 行，或 `lmsys33k` 共 `78,540` 行）重新执行训练，并导出用于离线提交的两个独立验证产物：
1. **`adapter.pt`**：保存训练后的 FP32 SR2 分类头权重 `head_state_dict`（含 `input_projection.weight`、`win_projection_bias`、`win_readout.weight`、`u`、`tie_bias` 以及固定缓冲区 `t`）以及与底座校验所需的元信息（剥离优化器状态以最小化体积）。
2. **`merged/`**：对于 `SR2-Qwen3-4B-lora` 全量构建，将训练模型切至评估模式并移至 CPU，调用 `merge_and_unload(safe_merge=True)` 将 LoRA 低秩增量 $\Delta W = \frac{\alpha}{r} B A$ 无损合并入原始 Qwen3 主干权重，以原始精度（BF16）按最大 `5 GB` 分片导出为 Safetensors 权重，连同分词器配置、`chat_template.jinja` 与记录了 `checkpoint_sha256` 绑定摘要的 `export_metadata.json` 一并经临时暂存检验后原子发布。

---

## 2. Kaggle 双 T4 离线推理架构（`submit.ipynb`）

Kaggle 竞赛评测容器为**无互联网（Offline）、双卡 NVIDIA T4（16 GB × 2 = 32 GB VRAM）、Python 3.13+** 环境，且存在 Turing 架构不支持原生 BF16 Tensor Core 计算的硬件局限。为此，本项目编写了完全自包含的独立推理笔记本 `submit.ipynb`（不依赖本地项目包，目标环境要求 PyTorch `>= 2.14.0+cu130` 与 Transformers `>= 5.17.0`），通过七项系统优化确保稳定高效生成 `submission.csv`：

```mermaid
flowchart LR
    Test["test.csv\nChatML 序列化 + Blake2b 分支去重"] --> Pack["降序 DP / Best-Fit 打包\ntoken_budget=32768, max_rows=128"]
    Pack --> Stage0["GPU 0 (T4 #1)\nEmbed + Layers 0..17 (FP16)\n异步双批重叠 k+1"]
    Stage0 --> Stage1["GPU 1 (T4 #2)\nLayers 18..35 (FP16)\nPre-Norm 末位真实 Token 池化"]
    Stage1 --> Head["FP32 SR2 v10 分类头\nSoftmax(logits / T)"]
    Head --> Out["submission.csv 严格校验\n无 NaN, 行和=1, ID 对齐"]
```

1. **启动诊断与环境冲突清理**：在导入 PyTorch 前预置 `PYTORCH_ALLOC_CONF=expandable_segments:True` 与 `HF_HUB_OFFLINE=1`；自动卸载容器内与 CUDA 13.0 PyTorch 构建不兼容的预装 `torchaudio`；并在加载权重前执行依赖最低版本与 SDPA/Qwen3 接口完整性预检。
2. **分支去重与零截断 DP 打包**：利用 `Blake2b(16 bytes)` 对所有测试分支序列去重（相同 Prompt 下的重复历史或同分支只需编码一次），随后按长度降序排列并对比 Best-Fit 与连续动态规划（`token_budget = 32,768`、`max_rows_per_batch = 128`），全程**绝不截断**任何测试对话。
3. **零主机内存峰值的流式双卡模型切分（`SplitBackbone`）**：先在 `meta` 设备构建空壳模型，再直接从 Safetensors 分片逐张量读取并转为 **FP16**，直接送往目标 GPU（Embedding 与 `0..17` 层放于 `cuda:0`，`18..35` 层与最终 `norm` 放于 `cuda:1`），避免了模型先载入 CPU RAM 再搬运的双重内存占用与 `accelerate` 钩子开销，并兼容分卷上传产生 `-00Y` 后缀分片的自动软链接恢复。
4. **双阶段异步流水线并发（`pipeline_depth = 2`）**：借助 Pinned Memory 与 CUDA Events 队列，允许 `cuda:0` 提前计算批次 $k+1$ 的前半部分网络，同时 `cuda:1` 完成批次 $k$ 的后半部分网络并将池化向量异步拷回主机，显著隐藏跨 PCIe 中间隐状态传输延迟。
5. **Pre-Norm 末位池化规避显存爆炸**：在 `cuda:1` 上**先抽取每个样本的末位真实 Token 隐向量 `[batch, 2560]`，再送入 `Qwen3RMSNorm`** 并转为 FP32，彻底消除了整段超长序列 `[batch, seq_len, 2560]` 在 FP32 方差归一化下产生巨额临时张量导致 OOM 的风险。
6. **T4 专用 SDPA 内核调优**：默认设置 `use_gqa = "off"`（显式重复 K/V 头以保持 T4 上的 Memory-Efficient 注意力内核可用，禁用低速回退；亦支持 `"auto"` 在长上下文上实测对比原生 GQA 延迟与显存峰值）。
7. **温度校准与 OOM / FP16 溢出保护**：支持全局可调温度系数 `TEMPERATURE`（`softmax(logits / T)`，默认 `1.0`）；若运行期偶发 OOM，自动排空在途批次并减半 `token_budget` 重试；若极少数极端长度样本触发 FP16 溢出（非有限特征）或单样本 OOM，优雅回退至经验类先验 `(0.349, 0.342, 0.309)` 并统计在 `prior-filled rows` 日志中以便人工核验（正常提交应确保 `prior-filled rows: 0`）。

---

## 3. Kaggle 测试结果与排行榜信息后补模板（待填入）

> **使用说明**：当前压缩包暂缺最终 Kaggle 全量测试集推理日志与排行榜提交截图。完成提交后，请将运行结果与截图直接填入下方占位表格并同步更新至最终 LaTeX 报告第 4 节（Experiment）。

### 3.1 提交模型构建与推理配置记录（待补）

| 项目 | 填写内容（示例/待补） |
| :--- | :--- |
| **最终提交采用的训练配置** | `[例如：configs/l1.yaml (lmsys33k 78,540 行) / configs/1.yaml (external_merged 66,411 行) / 多模型概率集成]` |
| **模型架构与参数** | `Skywork-Reward-V2-Qwen3-4B` (+ 可选 LoRA $r=16, \alpha=32$) + `SR2 v10` ($t=\dots$) |
| **`submit.ipynb` 推理温度 `TEMPERATURE`** | `[例如：1.0]` |
| **实际打包与编码统计（`test.csv` 日志）** | 测试集总行数：`[待填]`；唯一分支数：`[待填]`；打包效率：`[待填 %]`；吞吐量：`[待填 tok/s]` |
| **稳定性检查** | 耗时：`[待填 min]`；OOM retries：`[待填]`；**`prior-filled rows`：`[目标为 0]`** |
| **预测类别均值分布** | `winner_model_a: [待填]` / `winner_model_b: [待填]` / `winner_tie: [待填]` |

### 3.2 Kaggle Leaderboard 成绩单（待补）

| 提交版本 | 模型描述 | Public Score (Log Loss) | Private Score (Log Loss) | Private Rank / Total Teams | Percentile |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **Submission 1（待补）** | `[单模型 / 冻结头或 LoRA 全量构建]` | `[待填]` | `[待填]` | `[待填] / [总队伍数]` | `[待填 %]` |
| **Submission 2（可选对比）** | `[不同温度 T 或多模型概率融合]` | `[待填]` | `[待填]` | `[待填] / [总队伍数]` | `[待填 %]` |

### 3.3 排行榜截图插入提示（课程硬性要求）

NTU AI6102 Team Project Instructions 明确要求报告需同时包含 **Cross-validation / Holdout results** 与 **the screenshot of leaderboard results**：
- 请截取包含 **队伍名称（Team Name）、Private/Public Leaderboard 分数、排名位置** 的完整 Kaggle Leaderboard 网页截图（可参照课程说明幻灯片中的 Tabular Playground Series 截图范式）；
- 若竞赛已结束，Private Leaderboard 为最终评测成绩，建议优先在报告中展示 **Private Score** 界面与 **My Submissions** 页面中对应提交记录的 Score 对齐截图。
