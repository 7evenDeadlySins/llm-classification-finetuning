# 05. Kaggle Offline Inference Architecture & Submission Template

[Back to Main Guide](../README.md) · [Previous: Experiments & Result Analysis](04_experiments_and_analysis.md) · [Next: LaTeX Writing Guide & Conclusion](06_latex_writing_guide_and_conclusion.md)

---

## 1. Full-Data Model Export (`--build`) and Deliverable Artifacts

After identifying optimal configurations via holdout validation, full-build mode (`uv run model SR2-Qwen3-4B --config <CONFIG> --build` for frozen head, or `uv run model SR2-Qwen3-4B-lora --config <CONFIG> --build` for LoRA joint fine-tuning) retrains on **all available training and validation rows** (e.g., `66,411` rows for `external_merged` or `78,540` rows for `lmsys33k`) and exports two verified artifacts for offline submission:
1. **`adapter.pt`**: Stores the trained FP32 SR2 classification head `head_state_dict` (`input_projection.weight`, `win_projection_bias`, `win_readout.weight`, `u`, `tie_bias`, and fixed buffer `t`) plus backbone verification metadata, stripping optimizer states to minimize size.
2. **`merged/`**: For `SR2-Qwen3-4B-lora` full builds, switches the model to eval mode on CPU, calls `merge_and_unload(safe_merge=True)` to fold LoRA increments $\Delta W = \frac{\alpha}{r} B A$ losslessly into the Qwen3 weights, and exports `5 GB`-sharded Safetensors in native BF16 along with tokenizer files, `chat_template.jinja`, and `export_metadata.json` (recording `checkpoint_sha256`) via atomic staging.

---

## 2. Kaggle Dual-T4 Offline Inference Architecture (`submit.ipynb`)

The Kaggle evaluation container runs **offline (no internet)** on **dual NVIDIA T4 GPUs (16 GB × 2 = 32 GB VRAM)** with **Python 3.13+**, where Turing-architecture T4s lack native BF16 Tensor Cores. Our self-contained submission notebook `submit.ipynb` (zero local package dependencies; targeting PyTorch `>= 2.14.0+cu130` and Transformers `>= 5.17.0`) incorporates seven system optimizations to generate `submission.csv` reliably:

```mermaid
flowchart LR
    Test["test.csv\nChatML Serialization + Blake2b Branch Dedup"] --> Pack["Descending DP / Best-Fit Packing\ntoken_budget=32768, max_rows=128"]
    Pack --> Stage0["GPU 0 (T4 #1)\nEmbed + Layers 0..17 (FP16)\nAsync Double-Buffering k+1"]
    Stage0 --> Stage1["GPU 1 (T4 #2)\nLayers 18..35 (FP16)\nPre-Norm Final-Token Pooling"]
    Stage1 --> Head["FP32 SR2 v10 Head\nSoftmax(logits / T)"]
    Head --> Out["submission.csv Strict Validation\nNo NaN, Row Sum=1, ID Aligned"]
```

1. **Startup diagnostics and conflict cleanup**: Sets `PYTORCH_ALLOC_CONF=expandable_segments:True` and `HF_HUB_OFFLINE=1` before importing PyTorch; removes preinstalled `torchaudio` incompatible with CUDA 13.0 PyTorch; and verifies minimum package versions and SDPA/Qwen3 interfaces prior to weight loading.
2. **Branch deduplication and zero-truncation DP packing**: Deduplicates test branches via `Blake2b(16 bytes)` (encoding shared prompt histories or identical branches only once), sorts descending by length, and selects between Best-Fit and contiguous DP (`token_budget = 32,768`, `max_rows_per_batch = 128`) with **zero truncation**.
3. **Zero-host-RAM-spike streaming sharding (`SplitBackbone`)**: Instantiates an empty model on `meta`, streams tensors directly from Safetensors shards, casts to **FP16**, and places them onto target GPUs (Embedding + layers `0..17` on `cuda:0`; layers `18..35` + final `norm` on `cuda:1`), eliminating double CPU-RAM overhead and `accelerate` hook latency while supporting `-00Y`-suffixed dataset upload symlinks.
4. **Two-stage asynchronous pipeline concurrency (`pipeline_depth = 2`)**: Uses pinned memory and CUDA event queues so `cuda:0` processes batch $k+1$ while `cuda:1` finishes batch $k$ and copies pooled vectors back to host asynchronously, hiding PCIe transfer latency.
5. **Pre-Norm final-token pooling**: Extracts each sample's final real token vector `[batch, 2560]` on `cuda:1` **before** applying `Qwen3RMSNorm` and casting to FP32, avoiding OOM from full-sequence `[batch, seq_len, 2560]` FP32 variance normalization.
6. **T4-tuned SDPA kernels**: Defaults to `use_gqa = "off"` (explicitly repeating K/V heads to keep T4 Memory-Efficient attention active and avoid slow fallbacks; also supports `"auto"` for benchmarking native GQA on long contexts).
7. **Temperature scaling and OOM / FP16 overflow protection**: Supports global `TEMPERATURE` (`softmax(logits / T)`, default `1.0`). On transient OOM, drains in-flight batches and halves `token_budget` for retry; on rare extreme-length FP16 overflow (non-finite features) or singleton OOM, gracefully falls back to the empirical prior `(0.349, 0.342, 0.309)` and logs `prior-filled rows` for verification (`0` expected in normal runs).

---

## 3. Kaggle Test Results & Leaderboard Template

> **Usage Note**: Five full-build Kaggle test scores are already recorded in [`kaggle-results-2026-11-19.md`](kaggle-results-2026-11-19.md). Once final inference logs and leaderboard screenshots are collected, populate the placeholder fields below and include them in Section 4 (Experiments) of the final LaTeX report.

### 3.1 Submission Build and Inference Configuration Log (Pending Full Details)

| Item | Entry (Example / To Be Filled) |
| :--- | :--- |
| **Final Submission Training Config** | `[e.g., configs/l2.yaml / l3.yaml (lmsys33k 78,540 rows) / probability ensemble]` |
| **Model Architecture & Parameters** | `Skywork-Reward-V2-Qwen3-4B` (+ optional LoRA $r=16, \alpha=32$) + `SR2 v10` ($t=\dots$) |
| **`submit.ipynb` Inference `TEMPERATURE`** | `[e.g., 1.0]` |
| **Packing & Encoding Stats (`test.csv` log)** | Total test rows: `[TBD]`; Unique branches: `[TBD]`; Packing efficiency: `[TBD %]`; Throughput: `[TBD tok/s]` |
| **Stability Check** | Runtime: `[TBD min]`; OOM retries: `[TBD]`; **`prior-filled rows`: `[Target: 0]`** |
| **Mean Predicted Class Distribution** | `winner_model_a: [TBD]` / `winner_model_b: [TBD]` / `winner_tie: [TBD]` |

### 3.2 Kaggle Leaderboard Scorecard (See [`kaggle-results-2026-11-19.md`](kaggle-results-2026-11-19.md) for Submitted Runs)

| Submission Version | Model Description | Public Score (Log Loss) | Private Score (Log Loss) | Private Rank / Total Teams | Percentile |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **Submission 1** | `[Single model / Frozen head or LoRA full build]` | `[TBD]` | `[TBD]` | `[TBD] / [Total Teams]` | `[TBD %]` |
| **Submission 2 (Optional)** | `[Different temperature T or ensemble]` | `[TBD]` | `[TBD]` | `[TBD] / [Total Teams]` | `[TBD %]` |

### 3.3 Leaderboard Screenshot Guidelines (Course Requirement)

NTU AI6102 Team Project Instructions explicitly require both **Cross-validation / Holdout results** and **the screenshot of leaderboard results**:
- Capture a full Kaggle Leaderboard screenshot clearly showing **Team Name, Private/Public Leaderboard Score, and Rank** (following the Tabular Playground Series example in the course slides);
- If the competition has closed, the Private Leaderboard is the final score—prioritize showing the **Private Score** view alongside the corresponding entry on **My Submissions**.
