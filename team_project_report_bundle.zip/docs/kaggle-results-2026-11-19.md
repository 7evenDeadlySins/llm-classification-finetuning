# Kaggle Test Results and Configuration Differences (2026-11-19)

[Documentation Index](../README.md) · [Kaggle Inference & Submission Template](05_kaggle_inference_and_submission_template.md)

This document records the Kaggle competition test scores and corresponding configuration differences across five full-build models. All five training runs use `data/processed/lmsys33k/train_validation.parquet` (all `78,540` rows, with no additional ranking filters or supplementary datasets), the `Skywork/Skywork-Reward-V2-Qwen3-4B` backbone, and `bf16` / `sdpa` precision settings, generated from `configs/l1.yaml`, `configs/l2.yaml`, and `configs/l3.yaml`, respectively.

## Test Results and Configuration Summary

| Model | Config File | Key Configuration Differences | Kaggle Score |
| --- | --- | --- | ---: |
| `SR2-Qwen3-4B` | `configs/l2.yaml` | `build_min_lr = 8.1e-05` | 0.91887 |
| `SR2-Qwen3-4B` | `configs/l3.yaml` | `build_min_lr = 9.411817e-05` | 0.92105 |
| `SR2-Qwen3-4B-lora` | `configs/l1.yaml` | `min_lr_ratio = 0.0`, `lr_decay_delay_epochs = 0` (default) | 0.89724 |
| `SR2-Qwen3-4B-lora` | `configs/l2.yaml` | `min_lr_ratio = 0.25`, `lr_decay_delay_epochs = 0` (default) | 0.88924 |
| `SR2-Qwen3-4B-lora` | `configs/l3.yaml` | `min_lr_ratio = 0.0`, `lr_decay_delay_epochs = 1` | 0.88950 |

## Configuration Details Comparison

All five builds share the same common hyperparameters: `max_length = 35130`, classification head `hidden_size = 128`, `dropout = 0.1`, `learning_rate = 0.0001`, `weight_decay = 0.01`, `random_state = 42`, and no label smoothing. Their differences lie primarily in model architecture and learning-rate decay schedules.

In terms of model architecture, the frozen-backbone scheme `SR2-Qwen3-4B` trains only `655,745` classification head parameters with exponential decay from `0.0001` over `build_epochs = 33`. Setting the final minimum learning rate to `8.1e-05` (`l2.yaml`) achieves `0.91887`, outperforming `0.92105` obtained with the higher terminal learning rate of `9.411817e-05` (`l3.yaml`).

By contrast, the LoRA joint fine-tuning scheme `SR2-Qwen3-4B-lora` improves the overall score by approximately `0.03`. This configuration has `33,685,889` trainable parameters (`lora_rank = 16`, `lora_alpha = 32`, `lora_dropout = 0.1`), completing `22` epochs of head warmup at a fixed `0.0001` learning rate followed by `2` epochs of cosine-decay joint training. Decaying directly to `0` from the first epoch (`l1.yaml`) yields a test score of `0.89724`; raising the terminal floor to `2.5e-05` (`min_lr_ratio = 0.25` in `l2.yaml`) or delaying decay until the second epoch (`lr_decay_delay_epochs = 1` in `l3.yaml`) improves online performance to `0.88924` and `0.88950`, respectively.
