# 01. Problem Statement & Core Challenges

[Back to Main Guide](../README.md) · [Next: Data Engineering & Multi-Source Alignment](02_data_engineering_and_audit.md)

---

## 1. Problem Statement

This project addresses the Kaggle competition **[LLM Classification Finetuning](https://www.kaggle.com/competitions/llm-classification-finetuning)**. Originating from real-world blind evaluations on Chatbot Arena, the task provides a single-turn or multi-turn conversation between a user and two anonymous large language models (Model A and Model B), and requires predicting the human judge's preference outcome.

### 1.1 Formal Formulation

For the $i$-th sample, the input consists of a shared sequence of user prompts and two sequences of model responses:

- **Prompt sequence**: $\mathbf{u}_i = (u_{i,1}, u_{i,2}, \dots, u_{i,T_i})$, where $T_i \ge 1$ denotes the number of conversation turns;
- **Model A response sequence**: $\mathbf{a}_i = (a_{i,1}, a_{i,2}, \dots, a_{i,T_i})$;
- **Model B response sequence**: $\mathbf{b}_i = (b_{i,1}, b_{i,2}, \dots, b_{i,T_i})$.

Note that model identities are **withheld at test time** (`model_a` and `model_b` appear only in training metadata for post-hoc distribution analysis and leakage checks, and are strictly excluded from model inputs). The output is a probability distribution over three mutually exclusive classes, $\hat{\mathbf{p}}_i = (\hat{p}_{i,0}, \hat{p}_{i,1}, \hat{p}_{i,2})$, corresponding to:
- $y_i = 0$: `winner_model_a` (Model A is preferred);
- $y_i = 1$: `winner_model_b` (Model B is preferred);
- $y_i = 2$: `winner_tie` (tie, encompassing both equally good and `both_bad` outcomes under original Arena rules).

### 1.2 Evaluation Metric and Baselines

The competition evaluates predictions using standard **three-class Multi-class Log Loss**:

$$
\mathcal{L}_{\text{log}} = -\frac{1}{N} \sum_{i=1}^{N} \sum_{c \in \{0, 1, 2\}} y_{i,c} \log\bigl(\operatorname{clip}(\hat{p}_{i,c}, \epsilon, 1 - \epsilon)\bigr),
$$

where $y_{i,c} \in \{0, 1\}$ is the ground-truth one-hot label, $\hat{p}_{i,c} \ge 0$, and $\sum_{c=0}^{2} \hat{p}_{i,c} = 1$. Throughout validation, we use exact cross-entropy loss without label smoothing (`label_smoothing = 0.0`) to match the online evaluation protocol.

On the project's unified **11,495-row frozen Kaggle validation set** (class counts: `A: 4,010 (34.8847%)`, `B: 3,927 (34.1627%)`, `Tie: 3,558 (30.9526%)`), two uninformative baselines serve as reference points:

| Uninformative Baseline | Predicted Probabilities $(p_A, p_B, p_{\text{tie}})$ | Frozen Val Log Loss | Accuracy |
| :--- | :---: | :---: | :---: |
| Uniform prediction | $(1/3,\; 1/3,\; 1/3)$ | **1.098612** | 33.33% (expected random) / 34.88% (deterministic `argmax`) |
| Competition empirical prior | $(0.348847,\; 0.341627,\; 0.309526)$ | **1.097283** | 34.88% |

Unlike Accuracy, which only measures hard decision boundaries, Log Loss heavily penalizes poor **probability calibration** and overconfident errors: the model must not only identify the stronger response, but also output well-calibrated conditional probabilities on ambiguous matchups.

---

## 2. Competition Data Profile

The core Kaggle benchmark dataset contains **57,477** blind human-evaluated battles involving **64** mainstream open-source and proprietary models from 2023–2024 (the five most frequent being `gpt-4-1106-preview`, `gpt-3.5-turbo-0613`, `gpt-4-0613`, `claude-2.1`, and `claude-instant-1`). After correcting labels for exact-match identical responses (`response_a == response_b`), the full 57,477-row dataset contains **17,788** ties (exactly `30.9480%`).

Under our fixed 80/20 split grouped by full prompt hash, stratified by label, and balanced by token count (detailed in [`02_data_engineering_and_audit.md`](02_data_engineering_and_audit.md)), the training and frozen validation splits exhibit the following statistics (token counts measured without truncation using the official `Skywork/Skywork-Reward-V2-Qwen3-4B` tokenizer and `sr2-qwen3-chat-template-v1`):

| Split | Battles | Prompt Groups | A / B / Tie | Multi-Turn Share | Mean Branch Tokens | Branch P95 / P99 / Max Tokens | Total A+B Tokens |
| :--- | ---: | ---: | :---: | ---: | ---: | :---: | ---: |
| **Kaggle Train** | 45,982 | 41,436 | 16,042 / 15,710 / 14,230 | 13.00% (5,976) | 389.89 | 1,045 / 2,244 / 13,866 | 35,856,134 |
| **Kaggle Frozen Val** | 11,495 | 10,298 | 4,010 / 3,927 / 3,558 | 13.60% (1,563) | 392.24 | 1,069 / 2,153 / 6,180 | 9,017,593 |

---

## 3. Five Core Technical Challenges

Centered on task structure, data characteristics, inductive bias, and hardware constraints, this project addresses five core challenges:

### Challenge 1: A/B Position Symmetry and Swap Equivariance

Model A and Model B are inherently interchangeable symmetric slots. Swapping the input from $(\mathbf{u}, \mathbf{a}, \mathbf{b})$ to $(\mathbf{u}, \mathbf{b}, \mathbf{a})$ requires an ideal classifier to satisfy:

$$
P(\text{A wins} \mid \mathbf{u}, \mathbf{b}, \mathbf{a}) = P(\text{B wins} \mid \mathbf{u}, \mathbf{a}, \mathbf{b}), \qquad
P(\text{Tie} \mid \mathbf{u}, \mathbf{b}, \mathbf{a}) = P(\text{Tie} \mid \mathbf{u}, \mathbf{a}, \mathbf{b}).
$$

Conventional single-sequence concatenation (e.g., `[Prompt] + [Response A] + [Response B]`) doubles self-attention context length and exposes autoregressive Transformers to position bias. Conversely, feeding concatenated dual-branch embeddings into a standard MLP does not enforce algebraic swap equivariance, forcing reliance on A/B flip augmentation and two-pass test-time averaging. Achieving strict equivariance architecturally in a **single forward pass (`original_only`)** is essential for efficient modeling.

### Challenge 2: Dual Semantics of Ties and the Dominant Error Region

Validation error decomposition (see [`04_experiments_and_analysis.md`](04_experiments_and_analysis.md)) shows that **the Tie class (Label 2) is the primary bottleneck governing overall Log Loss**. Across all 16 frozen-backbone runs, per-class Log Loss for Model A and Model B wins remains stably within **0.804–0.852** (`63.7%–67.7%` recall), whereas Tie Log Loss climbs to **0.997–1.105** (`37.3%–46.9%` recall), with most misclassifications concentrated along the win-versus-tie boundary.

This difficulty stems from the intrinsic heterogeneity of ties:
1. **Coexistence of high-quality parity and mutual failure**: Human-labeled ties cover both cases where two models deliver equally thorough, accurate answers and cases where both fail or refuse (`both_bad`). A single static similarity or absolute-difference feature struggles to capture both regimes simultaneously.
2. **Rare identical responses vs. abundant semantically close responses**: The raw competition data contains **27** noisy records where `response_a == response_b` was labeled as a win for one side. Meanwhile, among the 3,558 ties in the corrected validation set, only **42 (1.18%)** are literally identical, while the remaining **3,516 (98.82%)** differ lexically yet match in quality. The classification head must recognize the strong prior for identical responses without over-penalizing tie probabilities for distinct responses.

### Challenge 3: Zero-Truncation Modeling of Heavy-Tailed Long Contexts and Multi-Turn Dialogues

Although the median single-branch length in Kaggle Train is only **297 tokens**, the length distribution is heavily skewed: Kaggle reaches **13,866 tokens** per branch, while modern external Arena datasets reach **40,953 tokens** and feature far more multi-turn dialogues (`31.71%` in Arena Human, `35.72%` in Arena Expert).

Preference judgments often hinge on the final turn's response and its consistency with prior context. Slice metrics confirm that the `13.60%` (1,563 rows) multi-turn subset in validation consistently incurs higher Log Loss (`~0.905–0.914`) than single-turn rows (`~0.886–0.896`). Right-side truncation would discard the final turn and corrupt label causality, requiring **zero-truncation** encoding and batching up to `<= 40,960` tokens.

### Challenge 4: Volume Dominance, Generational Drift, and Noise in External Data

With only 45,982 rows (`41,436` prompt groups) in Kaggle Train, incorporating public human preference datasets is a natural way to improve generalization. However, integrating `lmsys/chatbot_arena_conversations`, `lmarena-ai/arena-human-preference-140k`, and `lmarena-ai/arena-expert-5k` reveals sharp distributional conflicts:
- **Model generation and stylistic divergence**: Collected in 2025, Arena Human 140K and Arena Expert 5K contain 53 and 103 newer models, respectively, with **zero exact name overlap** with Kaggle's 64 earlier models. Arena Human averages `1,638.76` tokens per branch (**4.20x** Kaggle), exhibits a `26.25%` Markdown heading rate (vs. `4.13%` in Kaggle), and is only `52.48%` English (`en`) across 126 languages.
- **Volume dominance and class-prior shift**: The 220,492-row pure-Arena merged pool contains 208,997 training rows, with Arena Human alone contributing `135,440` rows (**443.9M A+B tokens** vs. **35.9M** in Kaggle Train). Moreover, the unfiltered merged training tie rate drops to `28.52%`, below Kaggle's `30.95%`. Naive full mixing would overwhelm Kaggle's target distribution in sample count, token volume, and language style.
- **Subsequent evaluation turns and cross-source duplicate votes**: `20.12%` of Arena Human and `23.98%` of Arena Expert records represent follow-up evaluations (`evaluation_order > 1`) within the same session, alongside cross-dataset duplicates and 17 tied-vote conflicts, necessitating strict history reconstruction and hard-vote arbitration.

### Challenge 5: Extreme Hardware Asymmetry Between Training and Inference

Development training and competition inference operate under starkly different hardware constraints:
- **Training environment**: High-VRAM single-GPU setups (such as Colab G4 / RTX PRO 6000 Blackwell with `96 GB` VRAM and native `BF16` support), capable of handling `40,960`-token sequences via feature caching and DP token-budget packing.
- **Kaggle evaluation container**: Strictly **offline (no internet)** with **dual NVIDIA T4 GPUs (16 GB × 2 = 32 GB VRAM)**. Turing-architecture T4s **lack native BF16 Tensor Cores**, requiring FP16 inference and safeguards against activation overflow on long sequences. Because a single T4 cannot hold a 4B model plus long-context activations, the submission notebook must implement streaming layer sharding without host-RAM spikes, asynchronous pipeline scheduling, Pre-Norm pooling, and dynamic OOM backoff.
