# 06. 论文撰写映射、可用 LaTeX 素材与竞赛结论（Writing Guide & Conclusion）

[返回主说明](../README.md) · [上一篇：Kaggle 推理与结果后补模板](05_kaggle_inference_and_submission_template.md)

---

## 1. AI6102 报告提交核对表

在生成最终 PDF 报告并邮件发送给 **Dr. Yuan Zhou (`yuan.zhou@ntu.edu.sg`)** 与助教前，请逐项核对以下课程合规清单：

1. **身份信息完整性**：首页作者栏必须写齐**所有组员的英文全名（Full Name）与 NTU 学号（Matriculation Number）**（最多 3 人）。
2. **模板规范**：建议使用 **CVPR 2026 Author Kit** 或 **NeurIPS / ICML LaTeX** 双栏/单栏标准学术模板，编译为 `.pdf` 提交；**无需附带项目源代码**。
3. **硬性截止时间**：**2026 年 11 月 20 日（Week 14 结束）**，无延期通道。
4. **内容覆盖自查**：
   - [x] Problem statement in your own words（参见 [`01_problem_and_challenges.md`](01_problem_and_challenges.md) 第 1 节）
   - [x] Challenges of the problem（参见 [`01_problem_and_challenges.md`](01_problem_and_challenges.md) 第 3 节）
   - [x] Proposed solution — Motivation & Detailed steps（参见 [`02_data_engineering_and_audit.md`](02_data_engineering_and_audit.md) 与 [`03_model_architecture_and_training.md`](03_model_architecture_and_training.md)）
   - [x] Experiment — Motivation verification & Holdout results（参见 [`04_experiments_and_analysis.md`](04_experiments_and_analysis.md) 与 `results/`）
   - [ ] Experiment — Kaggle Leaderboard screenshot & test score（**暂缺待后补**，使用 [`05_kaggle_inference_and_submission_template.md`](05_kaggle_inference_and_submission_template.md) 模板填入）
   - [x] Conclusion — What we learned（参见本文件第 4 节）

---

## 2. 论文章节与本说明文档库映射关系

下表将标准 Kaggle Competition 论文的 6 个主要板块精确映射至本资料包的具体章节与实证表格，便于快速起草或分配组员并行撰写：

| 论文目标章节 | 建议篇幅分配 | 推荐参考本包文档位置 | 核心图表与关键数字 |
| :--- | :---: | :--- | :--- |
| **Title, Authors & Abstract** | 0.4 页 | [`../README.md`](../README.md) §2–3 | 摘要三要素：`Skywork-Reward-V2-Qwen3-4B`、`SR2 v10` 精确置换等变头、从 `1.0973` 先验大幅降至 `0.895180`（最优单组冻结模型）与 `0.893515`（16 组概率集成）；可选 LoRA 与 Kaggle 线上成绩待最终提交后补入 |
| **1. Introduction & Problem Statement** | 0.8 页 | [`01_problem_and_challenges.md`](01_problem_and_challenges.md) §1–3 | 多分类 Log Loss 公式、57,477 行规模、五大挑战（A/B 对称性与位置偏置、平局双重语义、40k 长尾零截断、纯 Arena 外部分布漂移、G4→T4×2 非对称硬件） |
| **2. Data Engineering & Distribution Audit** | 1.2 页 | [`02_data_engineering_and_audit.md`](02_data_engineering_and_audit.md) §1–5 | 分组 Token 均衡表（相对偏差 `0.4774%`）、纯 Arena 多源清洗（220,492 池）与基于 `30.95%` 平局对齐的 `lmsys33k` (67,045) vs `external_merged` 稀有度精选 (52,640) |
| **3. Proposed Method (SR2 & Training)** | 1.8 页 | [`03_model_architecture_and_training.md`](03_model_architecture_and_training.md) §1–4 | 体系架构图（双分支无掩码编码 + Pre-Norm 末位池化 + SR2 v10 数学公式 + $2Dh+3h+1=655,745$ 参数）、等变性证明、固定几何常数 $t$ 稳定性设计、两阶段预热+LoRA（`33,030,144` / 33.69M 参数）、DP 打包 + 自适应 Checkpointing |
| **4. Experiments & Ablation Analysis** | 2.0 页 | [`04_experiments_and_analysis.md`](04_experiments_and_analysis.md) §1–2 + [`05_kaggle...`](05_kaggle_inference_and_submission_template.md) §2–3 | 16 组冻结头矩阵表、$t \in \{\phi, \sqrt{5}, \sqrt{5}+\phi^{-1}\}$ 与 `factor` 消融、子集（单/多轮、长短文、同/异回复平局）剖析、3×3 混淆矩阵、包内集成（`0.893515` / `0.893941`）与 **Kaggle 排行榜截图（待补）** |
| **5. Conclusion & Lessons Learned** | 0.5 页 | 本文档第 4 节 | 5 条竞赛方法论总结与未来改进方向 |

---

## 3. 可直接复用的英文 LaTeX 数学公式与关键术语片段

若采用英文撰写 LaTeX 论文，以下关键公式经过代码逐行核验，可直接复制至 `.tex` 源文件中使用：

### 3.1 SR2 v10 Swap-Equivariant Head Formulation

```latex
\begin{equation}
\begin{aligned}
P_A &= \operatorname{GELU}(\mathbf{A}L - \mathbf{B}M + B_1), \qquad
P_B = \operatorname{GELU}(\mathbf{B}L - \mathbf{A}M + B_1), \\
W_A &= P_A \odot m_P, \qquad W_B = P_B \odot m_P, \\
z_A &= W_A R, \qquad z_B = W_B R, \\
C_A &= \max(W_A, 0), \qquad C_B = \max(W_B, 0), \\
u_{\mathrm{eff}} &= s \operatorname{softplus}(u / s), \qquad s = 0.01, \\
z_{\mathrm{tie}} &= b_{\mathrm{tie}} + \bigl(C_A + C_B - t \, |C_A - C_B|\bigr) u_{\mathrm{eff}}.
\end{aligned}
\end{equation}
```

### 3.2 Multi-Class Log Loss Objective

```latex
\begin{equation}
\mathcal{L}_{\text{log}} = -\frac{1}{N} \sum_{i=1}^{N} \sum_{c \in \{0,1,2\}} y_{i,c} \log\bigl(\hat{p}_{i,c}\bigr), \qquad
\hat{\mathbf{p}}_i = \operatorname{Softmax}\bigl([z_{A,i},\, z_{B,i},\, z_{\mathrm{tie},i}] / \tau\bigr).
\end{equation}
```

### 3.3 Token-Budgeted Micro-Batch Cost

```latex
\begin{equation}
\mathcal{C}(\mathcal{B}) = |\mathcal{B}| \cdot \Bigl(\max_{i \in \mathcal{B}} L_{A,i} + \max_{i \in \mathcal{B}} L_{B,i}\Bigr) \le B_{\mathrm{ckpt}}.
\end{equation}
```

---

## 4. 研究结论与竞赛收获总结（Conclusion: What We Learned）

回顾从偏好骨干选型、纯 Arena 数据对齐、精确置换等变分类头定型，到 16 组受控实验评估与不对称硬件工程落地的完整周期，团队在机器学习方法论与大规模 LLM 工程实践上获得了五项深刻认识：

1. **奖励表征迁移是偏好预测的高效杠杆**：相比从通用文本生成模型从零适配，选用已在人类偏好对比上对齐的奖励模型（`Skywork-Reward-V2-Qwen3-4B`）作为骨干，即使完全冻结主干、仅训练 `655,745` 个参数（占 4B 骨干不到 `0.02%`）的分类头，即可在 11,495 条留出验证集上将 Log Loss 从无信息先验 `1.0973` 大幅压低至 **`0.895180`**（单组最优）与 **`0.893515`**（16 组集成），且单次特征训练仅需 20–35 秒与不足 `0.11 GiB` 显存；在此之上，项目亦完整设计了低秩适应管线（LoRA $r=16, \alpha=32$ 配合已训练头部预热，仅微调不到 `1%` 的总参数量）以便全量构建使用。
2. **结构归纳偏置（Inductive Bias）远胜朴素数据增强**：将置换等变性直接刻入比较头的交叉投影（$L, M$ 反对称配合末维读取）与对称非线性几何（$C_A + C_B - t|C_A - C_B|$）后，模型在零 A/B 翻转样本增强下实现了高度对称的均值概率校准（$|P(A)-P(B)| \le 0.0014$），使训练与推理吞吐量直接翻倍；同时将 $t$ 固定为黄金比例关联几何常数（以 $\sqrt{5} \approx 2.236068$ 为默认稳健基线，同时检验 $\phi$ 与 $\sqrt{5}+\phi^{-1}$），避免了与平滑输出尺度参数 $u$ 耦合漂移的风险。
3. **数据时代匹配与高质量多轮长文本具有真实的互补泛化收益**：严格按 Prompt 去泄漏清洗纯 Arena 多源池（`220,492` 条候选），使我们清晰量化了两条外部构建路线的差异——高度贴合竞赛 `76.70%` 早期模型世代的 `lmsys33k`（`67,045` 行，在单轮与中短文本上占优，最优 `0.895180`），以及按英文稀有度精选且富含现代 Arena 对话的 `external_merged`（`52,640` 行，在多轮 `0.9051` 与 `>2048` 超长文本 `0.9911` 上显著反超 `lmsys33k`）。将同 $t=\sqrt{5}$ 下两个数据集的预测概率等权平均（`n=8`）即可将验证 Loss 一次性压低至 **`0.893941`**、准确率提升至 **`58.82%`**（全 16 组集成进一步降至 **`0.893515`**），远胜盲目堆砌异构样本。
4. **面向不对称硬件的零截断系统工程决定方案上限**：在对话评价任务中，末轮结论往往位于长序列尾部，强行截断会直接损毁标签真实性。通过利用因果自注意力的无掩码右填充加速、对比 DP 与 Best-Fit 的两阶段 Token 预算打包、自适应阈值 Gradient Checkpointing，以及提交端双 T4 卡的流式图层切分、异步流水线与 Pre-Norm 池化，团队得以在不牺牲任何单个 Token 的前提下，跨越从单卡 BF16 训练到 `16 GB × 2` FP16 离线推理的巨大硬件鸿沟。
5. **科学化的受控实验闭环是快速迭代的根基**：保持 11,495 条按 Prompt 严格分组的冻结验证集始终不变、借助内容寻址缓存将单次头实验周期压缩至约 1 分钟、以及坚持按类别（胜负 vs 平局）和对话形态（单/多轮、长度分段、字面相同/不同平局）的细粒度归因，使团队能够用客观数字驱动超参数网格与跨数据集集成决策。
