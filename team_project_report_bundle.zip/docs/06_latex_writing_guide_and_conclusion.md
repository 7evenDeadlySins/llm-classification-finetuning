# 06. LaTeX Writing Guide, Ready-to-Use Formulas & Conclusion

[Back to Main Guide](../README.md) · [Previous: Kaggle Inference & Submission Template](05_kaggle_inference_and_submission_template.md)

---

## 1. AI6102 Report Submission Checklist

Before compiling the final PDF report and emailing it to **Dr. Yuan Zhou (`yuan.zhou@ntu.edu.sg`)** and the TA, verify every item below:

1. **Complete Author Metadata**: List **all team members' Full English Names and NTU Matriculation Numbers** on the title page (maximum 3 members).
2. **Template Standard**: Use **CVPR 2026 Author Kit** or **NeurIPS / ICML LaTeX** standard academic formatting and submit as `.pdf`; **no source code submission is required**.
3. **Strict Deadline**: **November 20, 2026 (End of Week 14)**, with no extensions.
4. **Content Coverage Check**:
   - [x] Problem statement in your own words ([`01_problem_and_challenges.md`](01_problem_and_challenges.md) §1)
   - [x] Challenges of the problem ([`01_problem_and_challenges.md`](01_problem_and_challenges.md) §3)
   - [x] Proposed solution — Motivation & Detailed steps ([`02_data_engineering_and_audit.md`](02_data_engineering_and_audit.md) & [`03_model_architecture_and_training.md`](03_model_architecture_and_training.md))
   - [x] Experiment — Motivation verification & Holdout results ([`04_experiments_and_analysis.md`](04_experiments_and_analysis.md) & `results/`)
   - [x] Experiment — Kaggle test scores ([`kaggle-results-2026-11-19.md`](kaggle-results-2026-11-19.md); leaderboard screenshot pending insertion per [`05_kaggle_inference_and_submission_template.md`](05_kaggle_inference_and_submission_template.md))
   - [x] Conclusion — What we learned (Section 4 below)

---

## 2. Paper Section-to-Bundle Mapping

The table below maps the six standard sections of a Kaggle competition paper directly to the bundle's documentation and empirical tables for parallel drafting:

| Target Paper Section | Suggested Length | Recommended Bundle Reference | Key Figures & Numbers |
| :--- | :---: | :--- | :--- |
| **Title, Authors & Abstract** | 0.4 pages | [`../README.md`](../README.md) §2–3 | Core triad: `Skywork-Reward-V2-Qwen3-4B`, `SR2 v10` swap-equivariant head, Log Loss reduced from `1.0973` prior to `0.895180` (best single frozen run) and `0.893515` (16-run ensemble); LoRA full-build Kaggle scores (`0.88924` / `0.88950`) |
| **1. Introduction & Problem Statement** | 0.8 pages | [`01_problem_and_challenges.md`](01_problem_and_challenges.md) §1–3 | Multi-class Log Loss equation, 57,477-row profile, five challenges (A/B symmetry & position bias, dual-semantic ties, 40k zero-truncation, pure-Arena distribution drift, G4→T4×2 hardware asymmetry) |
| **2. Data Engineering & Distribution Audit** | 1.2 pages | [`02_data_engineering_and_audit.md`](02_data_engineering_and_audit.md) §1–5 | Grouped token-balanced split (`0.4774%` token deviation), pure-Arena multi-source cleaning (220,492 pool), `30.95%`-tie-aligned `lmsys33k` (67,045) vs. `external_merged` rarity selection (52,640) |
| **3. Proposed Method (SR2 & Training)** | 1.8 pages | [`03_model_architecture_and_training.md`](03_model_architecture_and_training.md) §1–4 | Architecture diagram (unmasked dual-branch encoding + Pre-Norm pooling + SR2 v10 equations + $2Dh+3h+1=655,745$ params), equivariance proof, fixed $t$ stability, two-stage warmup + LoRA (`33,030,144` / 33.69M params), DP packing + adaptive checkpointing |
| **4. Experiments & Ablation Analysis** | 2.0 pages | [`04_experiments_and_analysis.md`](04_experiments_and_analysis.md) §1–2 + [`kaggle-results-2026-11-19.md`](kaggle-results-2026-11-19.md) + [`05_kaggle...`](05_kaggle_inference_and_submission_template.md) §2–3 | 16-run frozen matrix, $t \in \{\phi, \sqrt{5}, \sqrt{5}+\phi^{-1}\}$ & `factor` ablations, slice analysis (single/multi-turn, length, same/diff ties), 3×3 confusion matrices, ensembles (`0.893515` / `0.893941`), 5 Kaggle full builds (`0.88924` best LoRA), leaderboard screenshot (pending) |
| **5. Conclusion & Lessons Learned** | 0.5 pages | Section 4 of this file | Five methodological takeaways and future directions |

---

## 3. Verified LaTeX Equations for Direct Reuse

The following equations have been verified line-by-line against the codebase and can be copied directly into `.tex` sources:

### 3.1 SR2 v10 Swap-Equivariant Head Formulation

```latex
\begin{equation}
\begin{aligned}
P_A &= \operatorname{GELU}(\mathbf{A}L - \mathbf{B}M + B_1), \qquad
P_B = \operatorname{GELU}(\mathbf{B}L - \mathbf{A}M + B_1), \\
W_A &= P_A \odot m_P, \qquad W_B = P_B \odot m_P, \\
z_A &= W_A R, \qquad z_B = W_B R, \\
C_A &= \max(W_A, 0), \qquad C_B = \max(W_B, 0), \\
u_{\mathrm{eff}} &= s \operatorname{softplus}(u / s), \qquad s = 0.01, \\
z_{\mathrm{tie}} &= b_{\mathrm{tie}} + \bigl(C_A + C_B - t \, |C_A - C_B|\bigr) u_{\mathrm{eff}}.
\end{aligned}
\end{equation}
```

### 3.2 Multi-Class Log Loss Objective

```latex
\begin{equation}
\mathcal{L}_{\text{log}} = -\frac{1}{N} \sum_{i=1}^{N} \sum_{c \in \{0,1,2\}} y_{i,c} \log\bigl(\hat{p}_{i,c}\bigr), \qquad
\hat{\mathbf{p}}_i = \operatorname{Softmax}\bigl([z_{A,i},\, z_{B,i},\, z_{\mathrm{tie},i}] / \tau\bigr).
\end{equation}
```

### 3.3 Token-Budgeted Micro-Batch Cost

```latex
\begin{equation}
\mathcal{C}(\mathcal{B}) = |\mathcal{B}| \cdot \Bigl(\max_{i \in \mathcal{B}} L_{A,i} + \max_{i \in \mathcal{B}} L_{B,i}\Bigr) \le B_{\mathrm{ckpt}}.
\end{equation}
```

---

## 4. Conclusion: What We Learned

Reflecting on the full lifecycle—from reward-backbone selection, pure-Arena data alignment, and swap-equivariant head design to 16 controlled validation runs, 5 full-build Kaggle submissions, and asymmetric hardware engineering—our team distilled five key lessons:

1. **Reward representation transfer is a high-leverage starting point for preference prediction**: Compared to adapting a general-purpose generative LLM from scratch, starting from a preference-aligned reward model (`Skywork-Reward-V2-Qwen3-4B`) allows training just `655,745` head parameters (under `0.02%` of the 4B backbone) on frozen features to cut holdout Log Loss from `1.0973` to **`0.895180`** (best single run) and **`0.893515`** (16-run ensemble) in 20–35 seconds and `< 0.11 GiB` VRAM. Adding warmed-up LoRA joint fine-tuning ($r=16, \alpha=32$, `< 1%` total parameters) further improves Kaggle test scores by ~`0.03` (reaching `0.88924`).
2. **Structural inductive bias outperforms naive data augmentation**: Encoding swap equivariance directly into cross-projected win logits ($L, M$ antisymmetry) and symmetric tie geometry ($C_A + C_B - t|C_A - C_B|$) yields highly symmetric mean probabilities ($|P(A)-P(B)| \le 0.0014$) with zero A/B flip augmentation, doubling training and inference throughput. Fixing $t$ to golden-ratio-related constants ($\sqrt{5} \approx 2.236068$ as a robust default, alongside $\phi$ and $\sqrt{5}+\phi^{-1}$) prevents scale-coupling drift with $u_{\mathrm{eff}}$.
3. **Epoch-matched data and modern long-context multi-turn battles offer genuine complementarity**: Leakage-free cleaning of the 220,492-row pure-Arena pool clarifies the trade-off between `lmsys33k` (`67,045` rows, `76.70%` early-model overlap, stronger on single-turn and short contexts, best `0.895180`) and `external_merged` (`52,640` rarity-selected rows, stronger on multi-turn `0.9051` and `>2048`-token contexts `0.9911`). Equal-weight averaging across both at $t=\sqrt{5}$ (`n=8`) immediately lowers validation loss to **`0.893941`** (**`58.82%`** accuracy; **`0.893515`** across all 16 runs), far outperforming blind mixing of heterogeneous data.
4. **Zero-truncation systems engineering under hardware asymmetry sets the performance ceiling**: Because final-turn quality often decides preference labels, truncating long dialogues corrupts ground truth. Combining unmasked causal right-padding, DP vs. Best-Fit token-budget packing, adaptive gradient checkpointing, and dual-T4 streaming sharding with async pipelining and Pre-Norm pooling bridges single-GPU BF16 training and `16 GB × 2` FP16 offline inference without dropping a single token.
5. **A disciplined, controlled experimental loop enables rapid iteration**: Preserving an immutable 11,495-row prompt-grouped validation set, compressing head ablations to ~1 minute via content-addressed feature caching, and decomposing errors by class (win vs. tie) and dialogue regime (turns, length, identical vs. distinct ties) grounded every design choice in objective empirical evidence.
