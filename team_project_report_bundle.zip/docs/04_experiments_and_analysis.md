# 04. Experimental Design & Result Analysis

[Back to Main Guide](../README.md) · [Previous: Model Architecture & Training](03_model_architecture_and_training.md) · [Next: Kaggle Inference & Submission Template](05_kaggle_inference_and_submission_template.md)

---

## 1. Unified Benchmark and Evaluation Protocol

To ensure strict scientific comparability, **all experiments reported here are evaluated on the identical 11,495-row frozen Kaggle holdout validation set** (`validation_ids.csv`) using single-direction inference (`prediction_aggregation = "original_only"`), measured by **unsmoothed Multi-class Log Loss**.

- **Validation composition**: `11,495` rows (`10,298` non-overlapping prompt groups), distributed as **Model A wins: 4,010 (34.8847%)**, **Model B wins: 3,927 (34.1627%)**, and **Tie: 3,558 (30.9526%)**.
- **Diagnostic slices**: Single-turn `9,932` rows (86.40%), multi-turn `1,563` rows (13.60%); distinct-response ties `3,516` rows, identical-response ties `42` rows; max branch length `<= 512` tokens `8,213` rows, `513–2,048` tokens `3,118` rows, `> 2,048` tokens `164` rows.
- **Uninformative baselines**: Uniform `(1/3, 1/3, 1/3)` yields Log Loss = **1.098612** (33.33% expected random accuracy, 34.88% majority-class `argmax`); empirical validation prior `(0.348847, 0.341627, 0.309526)` yields Log Loss = **1.097283** (34.88% accuracy).

> **Artifact Scope**: Section 2 analyzes the **16** controlled frozen-head validation experiments delivered in [`../results/`](../results/). Five full-build Kaggle test scores are recorded in [`kaggle-results-2026-11-19.md`](kaggle-results-2026-11-19.md), while leaderboard screenshots remain to be inserted per [`05_kaggle_inference_and_submission_template.md`](05_kaggle_inference_and_submission_template.md).

---

## 2. Full Statistics of the 16 Controlled Frozen-Head Experiments (`results/`)

All 16 runs use **`SR2-Qwen3-4B` (frozen `Skywork-Reward-V2-Qwen3-4B` + `swap_equivariant_abs_diff_v10` head)** with fixed initial LR `1e-4`, batch size `1024`, hidden size `128`, dropout `0.1`, weight decay `0.01`, random seed `42`, `patience = 2`, and `early_stopping = 5`, systematically varying three axes:
1. **Training data strategy**: `external_merged` English rarity selection (`52,640` train rows) vs. `lmsys33k` + 1,013 selected Arena ties (`67,045` train rows);
2. **Tie geometric penalty $t$**: An evenly spaced grid around the golden ratio $\phi = \frac{1+\sqrt{5}}{2}$: $\{\phi,\; \sqrt{5},\; \sqrt{5}+\phi^{-1}\} \approx \{1.618034,\; 2.236068,\; 2.854102\}$ (step $\phi^{-1} \approx 0.618034$);
3. **`ReduceLROnPlateau` decay `factor`**: `{0.95, 0.90, 0.85, 0.80}`.

### 2.1 Complete Metrics Across All 16 Runs

| Run Directory (`SR2-Qwen3-4B-...`) | Dataset (`Train Rows`) | Fixed $t$ | `factor` | `Best / Exec` Ep (LR Drops) | **Val Log Loss** | Acc | Macro F1 | Per-Class Log Loss `(A / B / Tie)` | Per-Class Recall `(A / B / Tie)` |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| [`20261118-183306`](../results/SR2-Qwen3-4B-20261118-183306/metrics.json) | `external_merged` (52,640) | 2.236068 | 0.95 | 46 / 51 (14) | 0.897444 | 58.49% | 57.76% | 0.8407 / 0.8397 / 1.0251 | 64.49% / 65.44% / 44.04% |
| [`20261118-183431`](../results/SR2-Qwen3-4B-20261118-183431/metrics.json) | `external_merged` (52,640) | 2.236068 | 0.90 | 52 / 57 (15) | 0.897391 | 58.39% | 57.32% | 0.8134 / 0.8122 / 1.0861 | 65.94% / 67.18% / 40.19% |
| [`20261118-183554`](../results/SR2-Qwen3-4B-20261118-183554/metrics.json) | `external_merged` (52,640) | 2.236068 | 0.85 | 52 / 57 (14) | **0.897158** | 58.52% | 57.85% | 0.8380 / 0.8366 / 1.0306 | 64.36% / 65.09% / 44.69% |
| [`20261118-183724`](../results/SR2-Qwen3-4B-20261118-183724/metrics.json) | `external_merged` (52,640) | 2.236068 | 0.80 | 56 / 61 (17) | 0.897352 | 58.47% | 57.69% | 0.8335 / 0.8331 / 1.0402 | 64.79% / 65.67% / 43.40% |
| [`20261118-232414`](../results/SR2-Qwen3-4B-20261118-232414/metrics.json) | `lmsys33k` (67,045) | 2.236068 | 0.95 | 49 / 54 (15) | **0.895348** | 58.48% | 57.88% | 0.8423 / 0.8412 / 1.0149 | 64.09% / 64.35% / 45.67% |
| [`20261118-232706`](../results/SR2-Qwen3-4B-20261118-232706/metrics.json) | `lmsys33k` (67,045) | 2.236068 | 0.90 | 33 / 43 (9) | 0.896361 | **58.56%** | **58.04%** | 0.8504 / 0.8520 / **0.9971** | 63.72% / 63.89% / **46.85%** |
| [`20261118-233019`](../results/SR2-Qwen3-4B-20261118-233019/metrics.json) | `lmsys33k` (67,045) | 2.236068 | 0.85 | 56 / 61 (22) | 0.895697 | 58.39% | 57.30% | 0.8133 / 0.8139 / 1.0788 | 66.53% / 66.72% / 40.02% |
| [`20261118-233314`](../results/SR2-Qwen3-4B-20261118-233314/metrics.json) | `lmsys33k` (67,045) | 2.236068 | 0.80 | 43 / 48 (15) | 0.896421 | 58.30% | 57.31% | 0.8245 / 0.8255 / 1.0558 | 66.01% / 66.18% / 40.92% |
| [`20261119-002359`](../results/SR2-Qwen3-4B-20261119-002359/metrics.json) | `lmsys33k` (67,045) | 1.618034 | 0.95 | 59 / 64 (20) | 0.895890 | 58.23% | 57.59% | 0.8352 / 0.8357 / 1.0307 | 63.97% / 64.50% / 44.86% |
| [`20261119-002516`](../results/SR2-Qwen3-4B-20261119-002516/metrics.json) | `lmsys33k` (67,045) | 1.618034 | 0.90 | 59 / 69 (15) | 0.895983 | 58.39% | 57.65% | 0.8294 / 0.8306 / 1.0432 | 64.91% / 64.96% / 43.79% |
| [`20261119-002628`](../results/SR2-Qwen3-4B-20261119-002628/metrics.json) | `lmsys33k` (67,045) | 1.618034 | 0.85 | 63 / 68 (12) | 0.895961 | 58.47% | 57.20% | 0.8051 / 0.8067 / 1.0969 | 67.21% / **67.74%** / 38.39% |
| [`20261119-002735`](../results/SR2-Qwen3-4B-20261119-002735/metrics.json) | `lmsys33k` (67,045) | 1.618034 | 0.80 | 44 / 49 (12) | 0.897737 | 58.16% | 56.79% | **0.8042** / **0.8052** / 1.1053 | **67.51%** / 67.53% / 37.27% |
| [`20261119-002836`](../results/SR2-Qwen3-4B-20261119-002836/metrics.json) | `lmsys33k` (67,045) | 2.854102 | 0.95 | 42 / 47 (14) | 0.897242 | 58.35% | 57.19% | 0.8115 / 0.8112 / 1.0888 | 66.71% / 67.05% / 39.32% |
| [`20261119-002945`](../results/SR2-Qwen3-4B-20261119-002945/metrics.json) | `lmsys33k` (67,045) | 2.854102 | 0.90 | 50 / 60 (13) | **0.895180** | 58.50% | 57.71% | 0.8265 / 0.8267 / 1.0483 | 65.49% / 65.24% / 43.20% |
| [`20261119-003052`](../results/SR2-Qwen3-4B-20261119-003052/metrics.json) | `lmsys33k` (67,045) | 2.854102 | 0.85 | 40 / 50 (12) | 0.895986 | 58.50% | 57.59% | 0.8222 / 0.8240 / 1.0587 | 66.01% / 65.90% / 41.88% |
| [`20261119-003159`](../results/SR2-Qwen3-4B-20261119-003159/metrics.json) | `lmsys33k` (67,045) | 2.854102 | 0.80 | 51 / 56 (13) | 0.896191 | 58.39% | 57.71% | 0.8346 / 0.8357 / 1.0323 | 64.51% / 64.73% / 44.49% |

### 2.2 Slice-Level Loss Breakdown and Resource Footprint

| Run Directory | Dataset & $t$ (`factor`) | Mean Pred Prob `(A / B / Tie)` | Single-Turn (9,932) | Multi-Turn (1,563) | Diff Tie (3,516) | Same Tie (42) | `<=512` / `513–2048` / `>2048` | Total Time (`Train` / `Peak VRAM MiB`) |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `20261118-183306` | `ext` 2.2361 (0.95) | 0.3418 / 0.3432 / 0.3150 | 0.8962 | **0.9051** | 1.0334 | 0.3312 | 0.8910 / 0.9093 / 0.9929 | `03:11` (`00:20` / 99.1) |
| `20261118-183431` | `ext` 2.2361 (0.90) | 0.3509 / 0.3521 / 0.2970 | 0.8959 | 0.9066 | 1.0955 | 0.2963 | 0.8908 / 0.9098 / 0.9925 | `01:20` (`00:22` / 99.1) |
| `20261118-183554` | `ext` 2.2361 (0.85) | 0.3426 / 0.3438 / 0.3136 | 0.8955 | 0.9075 | 1.0399 | 0.2510 | 0.8904 / 0.9101 / **0.9911** | `01:19` (`00:22` / 99.1) |
| `20261118-183724` | `ext` 2.2361 (0.80) | 0.3442 / 0.3454 / 0.3104 | 0.8957 | 0.9076 | 1.0496 | 0.2577 | 0.8910 / 0.9090 / 0.9917 | `01:26` (`00:24` / 99.1) |
| `20261118-232414` | `lms` 2.2361 (0.95) | 0.3408 / 0.3418 / 0.3174 | 0.8930 | 0.9102 | 1.0245 | **0.2094** | 0.8864 / 0.9118 / 1.0299 | `07:29` (`00:59` / 51.3) |
| `20261118-232706` | `lms` 2.2361 (0.90) | 0.3382 / 0.3389 / 0.3230 | 0.8942 | 0.9101 | **1.0060** | 0.2536 | 0.8890 / **0.9086** / 1.0342 | `02:43` (`00:48` / 51.3) |
| `20261118-233019` | `lms` 2.2361 (0.85) | 0.3507 / 0.3516 / 0.2977 | 0.8934 | 0.9104 | 1.0887 | 0.2534 | 0.8872 / 0.9109 / 1.0325 | `03:04` (`01:07` / 51.3) |
| `20261118-233314` | `lms` 2.2361 (0.80) | 0.3471 / 0.3480 / 0.3048 | 0.8942 | 0.9103 | 1.0651 | 0.2716 | 0.8884 / 0.9104 / 1.0326 | `02:46` (`00:53` / 51.3) |
| `20261119-002359` | `lms` 1.6180 (0.95) | 0.3431 / 0.3440 / 0.3129 | 0.8939 | 0.9085 | 1.0399 | 0.2593 | 0.8869 / 0.9133 / 1.0167 | `04:08` (`00:33` / 99.1) |
| `20261119-002516` | `lms` 1.6180 (0.90) | 0.3451 / 0.3459 / 0.3090 | 0.8939 | 0.9091 | 1.0526 | 0.2626 | 0.8872 / 0.9129 / 1.0155 | `01:13` (`00:35` / 99.1) |
| `20261119-002628` | `lms` 1.6180 (0.85) | 0.3528 / 0.3541 / 0.2930 | 0.8943 | 0.9067 | 1.1065 | 0.2917 | 0.8873 / 0.9127 / 1.0102 | `01:07` (`00:34` / 99.1) |
| `20261119-002735` | `lms` 1.6180 (0.80) | 0.3539 / 0.3553 / 0.2908 | 0.8960 | 0.9087 | 1.1149 | 0.2955 | 0.8899 / 0.9120 / 1.0189 | `01:02` (`00:25` / 99.1) |
| `20261119-002836` | `lms` 2.8541 (0.95) | 0.3519 / 0.3529 / 0.2952 | 0.8948 | 0.9126 | 1.0983 | 0.2980 | 0.8890 / 0.9122 / 1.0273 | `00:56` (`00:24` / 99.1) |
| `20261119-002945` | `lms` 2.8541 (0.90) | 0.3458 / 0.3469 / 0.3073 | **0.8924** | 0.9130 | 1.0578 | 0.2543 | **0.8857** / 0.9127 / 1.0344 | `01:04` (`00:30` / 99.1) |
| `20261119-003052` | `lms` 2.8541 (0.85) | 0.3476 / 0.3485 / 0.3039 | 0.8933 | 0.9128 | 1.0682 | 0.2640 | 0.8870 / 0.9125 / 1.0330 | `01:02` (`00:25` / 99.1) |
| `20261119-003159` | `lms` 2.8541 (0.80) | 0.3435 / 0.3443 / 0.3122 | 0.8935 | 0.9135 | 1.0419 | 0.2306 | 0.8866 / 0.9140 / 1.0360 | `01:03` (`00:28` / 99.1) |

*(Note: Longer total times on the first run of each batch such as `232414`, `183306`, and `002359` reflect initial sharded feature-cache loading; subsequent runs reusing the cache finish in `00:56`–`01:26` total and `20–35` seconds of pure training. Peak GPU VRAM across all 16 frozen-head runs stays between `51.3 MiB` (reserved `68.0 MiB`) and `99.1 MiB` (reserved `108.0 MiB`), i.e., under `0.11 GiB`.)*

### 2.3 Four Motivation Verifications and Key Insights

#### Finding 1: Dataset Structure and Generational Complementarity (`lmsys33k` vs. `external_merged` @ $t = \sqrt{5}$)
- **Overall winner**: Under identical architecture and $t = \sqrt{5}$, `lmsys33k` (mean `0.895957`, best `0.895348`) outperforms `external_merged` (mean `0.897336`, best `0.897158`) by **-0.001379** on average. Sharing 76.70% early-model overlap with Kaggle gives `lmsys33k` better calibration on single-turn (`0.8930–0.8942` vs. `0.8955–0.8962`) and short-to-medium (`<= 512` tokens: `0.8864` vs. `0.8904`) matchups.
- **Structural complementarity**: Conversely, `external_merged` decisively outperforms `lmsys33k` on **multi-turn dialogues** (best `0.9051` vs. `0.9101`) and **long contexts `> 2,048` tokens** (`0.9911–0.9929` vs. `1.0299–1.0342`, a **0.039** advantage), driven by its 6,658 modern multi-turn Arena battles.

#### Finding 2: Convergence Behavior of Tie Penalty $t$ ($t \in \{\phi, \sqrt{5}, \sqrt{5}+\phi^{-1}\}$ on `lmsys33k`)
- **Stability**: The default $t = \sqrt{5} \approx 2.236068$ yields the lowest group-mean loss (`0.895957`) and tightest spread (`0.895348–0.896421`, range `0.001073`), beating $\phi$ (`0.896393`, range `0.895890–0.897737`) and $\sqrt{5}+\phi^{-1}$ (`0.896150`, range `0.895180–0.897242`).
- **Single-run optimum**: Pairing $t = \sqrt{5}+\phi^{-1} \approx 2.854102$ with `factor = 0.90` achieves the **lowest single-run validation loss (`0.895180`)** in the matrix (`0.8924` on the 9,932 single-turn rows). Meanwhile, $t = \phi \approx 1.618034$ under-penalizes response differences; while occasionally helping `> 2048` contexts (`1.0102`), it under-predicts ties overall (e.g., `factor=0.80` drops mean tie probability to `0.2908`, pushing `Diff Tie` loss to `1.1149`).

#### Finding 3: Empirical A/B Symmetry and Confusion Matrix Analysis
Across all 16 runs, mean predicted $P(A)$ and $P(B)$ remain tightly symmetric (differing by only `0.0007`–`0.0014`, accurately tracking the validation split's `A: 34.88%` vs. `B: 34.16%` prior), confirming that **the SR2 architecture is inherently immune to position bias without A/B flip augmentation**.

Examining the 3×3 confusion matrices of two representative top runs (rows = true label, columns = predicted label):

| Best Single Loss `20261119-002945` (`lmsys33k`, $t=2.8541$, `LL=0.895180`) | Pred A | Pred B | Pred Tie | Most Balanced `20261118-232706` (`lmsys33k`, $t=\sqrt{5}$, `Acc=58.56%`) | Pred A | Pred B | Pred Tie |
| :--- | ---: | ---: | ---: | :--- | ---: | ---: | ---: |
| **True A (4,010)** | **2,626** (65.5%) | 677 | 707 | **True A (4,010)** | **2,555** (63.7%) | 666 | 789 |
| **True B (3,927)** | 693 | **2,562** (65.2%) | 672 | **True B (3,927)** | 667 | **2,509** (63.9%) | 751 |
| **True Tie (3,558)** | 974 | 1,047 | **1,537** (43.2%) | **True Tie (3,558)** | 906 | 985 | **1,667** (46.9%) |

Hard A-vs-B reversals account for only ~17.3% (`1,370 / 7,937`) and ~16.8% (`1,333 / 7,937`) of decisive battles, whereas the vast majority of errors lie along the **win-vs-tie boundary**, corroborating Challenge 2.

#### Finding 4: In-Bundle Probability Ensembling Confirms Data Complementarity
Averaging `validation.csv` probabilities equally across runs (no retraining required):

| Ensemble Combination | Members | Mean Member Log Loss | **Ensemble Log Loss** | Gain Over Mean | Ensemble Accuracy |
| :--- | :---: | :---: | :---: | :---: | :---: |
| `external_merged` ($t=\sqrt{5}$, 4 `factor`s) | 4 | 0.897336 | **0.896647** | -0.000689 | 58.57% |
| `lmsys33k` ($t=\phi$, 4 `factor`s) | 4 | 0.896393 | **0.895273** | -0.001120 | 58.50% |
| `lmsys33k` ($t=\sqrt{5}$, 4 `factor`s) | 4 | 0.895957 | **0.894941** | -0.001016 | 58.55% |
| `lmsys33k` ($t=\sqrt{5}+\phi^{-1}$, 4 `factor`s) | 4 | 0.896150 | **0.895246** | -0.000903 | 58.53% |
| `lmsys33k` All Runs (3 $t$ × 4 `factor`s) | 12 | 0.896166 | **0.894396** | -0.001770 | 58.64% |
| **Cross-Dataset @ $t=\sqrt{5}$ (`ext` 4 + `lms` 4)** | 8 | 0.896646 | **0.893941** | **-0.002705** | **58.82%** |
| **Full-Bundle 16-Run Ensemble** | 16 | 0.896459 | **0.893515** | **-0.002943** | 58.57% |

Averaging `external_merged` (`0.896647`) and `lmsys33k` (`0.894941`) at $t=\sqrt{5}$ drops Log Loss to **`0.893941`** and lifts accuracy to **`58.82%`** (with all 16 runs reaching **`0.893515`**), demonstrating genuine complementarity between epoch-matched early dialogues (`lmsys33k`) and modern long-context multi-turn Arena battles (`Ranked External`).
