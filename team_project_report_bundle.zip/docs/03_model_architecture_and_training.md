# 03. 模型架构、数学原理与训练优化（Architecture & Training Methodology）

[返回主说明](../README.md) · [上一篇：数据工程与分布对齐](02_data_engineering_and_audit.md) · [下一篇：实验设计与结果分析](04_experiments_and_analysis.md)

---

## 1. 骨干网络选型与无掩码提取设计

### 1.1 为何选择 `Skywork/Skywork-Reward-V2-Qwen3-4B`

传统方案通常基于通用指令微调或基座大语言模型从零学习三分类偏好，迫使分类器在有限对局样本上同时拟合“基础语义理解”与“回答优劣评价标尺”。本项目选用经过大规模高质量人类偏好对比对齐训练的奖励模型 **`Skywork/Skywork-Reward-V2-Qwen3-4B`**（锁定 Hub revision `fd958fef475f323f4e6b195930e3dd918485c668`）作为双分支共享骨干：
- **领域先验高度契合**：模型采用 36 层 Qwen3-4B 架构，隐藏维度 $D = 2560$，32 个 Query 头与 8 个 KV 头采用 GQA 分组查询注意力（单头维度 128），原生支持 `max_position_embeddings = 40,960` tokens。预训练阶段已将回答的准确性、逻辑完整性、指令遵循度与有用性高度浓缩至最终隐空间表示。
- **剥离标量输出并采用共享双分支编码**：加载 `AutoModel` 时丢弃原一维标量 `score` 线性头，保留最后一层隐藏状态输出。A、B 两条对话支路独立、并行通过同一个共享骨干编码，避免将两条对话拼接造成上下文翻倍与二次方注意力爆炸。

### 1.2 因果无掩码右填充与末位真实 Token 池化

利用 Qwen3 **严格因果自回归注意力（Causal Self-Attention）** 的数学性质——任意真实位置 Token 的隐状态仅取决于其本身及左侧历史，完全不感知右侧填充符：
- **传入 `attention_mask=None` 锁定融合内核**：微批次按各支路最长序列进行独立右侧填充，直接以 `attention_mask=None` 调用主干网络。此举使 PyTorch SDPA 无需退回通用掩码路径，并在上下文中通过 `sdpa_kernel([FLASH_ATTENTION, EFFICIENT_ATTENTION, CUDNN_ATTENTION])` 显式禁用二次方显存的 `math` 回退内核，显著提升吞吐并大幅降低超长序列显存占用。
- **末位真实 Token 精确池化**：在 CPU 端预计算每条分支未填充前的末位真实索引 $L_i - 1$，直接抽取 $\mathbf{h}_i \in \mathbb{R}^{2560}$ 作为支路语义特征向量。

---

## 2. SR2 v10 精确置换等变分类头（`swap_equivariant_abs_diff_v10`）

为从模型结构层面上根除 A/B 顺序偏置并精确刻画平局几何边界，项目采用 **`SwapEquivariantAbsoluteDifferenceClassificationHead`**（架构标识 `swap_equivariant_abs_diff_v10`，特征组合标识 `cross_projected_clamped_win_sum_diff`）。

```mermaid
flowchart LR
    HA["分支 A 池化向量 A (2560维)"] --> Stack["Packed Linear(D, 2h)\n共享权阵 L, M"]
    HB["分支 B 池化向量 B (2560维)"] --> Stack
    Stack --> Cross["交叉减法 + B1 + GELU\nP_A = GELU(AL - BM + B1)\nP_B = GELU(BL - AM + B1)"]
    Cross --> Drop["单样本共享 Dropout 掩码 m_P\nW_A, W_B"]
    Drop --> WinHead["共享胜负读出 W_A R, W_B R\n输出 logits z_A, z_B (FP32)"]
    Drop --> Clamp["转 FP32 并零处截断\nC_A = max(W_A,0), C_B = max(W_B,0)"]
    Clamp --> TieGeom["全精度对称几何聚合\nC_A + C_B - t * |C_A - C_B|"]
    TieGeom --> TieHead["正向软加权读出 u_eff + tie_bias\n输出 logit z_tie (FP32)"]
```

### 2.1 数学定义与精度实现

设骨干池化向量 $\mathbf{A}, \mathbf{B} \in \mathbb{R}^{D}$（本项目 $D = 2560$），分类器隐藏宽度 $h = 128$。设可学习矩阵 $L, M \in \mathbb{R}^{D \times h}$、隐藏偏置 $B_1 \in \mathbb{R}^{h}$、胜负读出向量 $R \in \mathbb{R}^{h \times 1}$、平局原始参数向量 $u \in \mathbb{R}^{1 \times h}$ 及标量偏置 $b_{\mathrm{tie}} \in \mathbb{R}$，并设固定正超参数 $t > 0$（存储为 FP32 常量 Buffer，默认 $t = \sqrt{5} \approx 2.236068$）。

在工程上，整个头部前向显式禁用自动混合精度（`torch.autocast(..., enabled=False)`）：当骨干计算精度为 `bf16` 时，胜负计算中的输入向量、`input_projection` 权重、`B1` 及 `R` 显式转为 `bfloat16`（若骨干为 `fp16` 或 `fp32` 则提取后的特征与头部均保持 `float32`）；随后将胜出激活转为全精度 `float32` 计算平局分支。具体分为四步：

1. **打包交叉投影与激活（Packed Linear）**：将 $(\mathbf{A}, \mathbf{B})$ 堆叠为 `[batch, 2, D]`，仅用**一次无偏置线性投影**同时求出 $\mathbf{A}L, \mathbf{A}M$ 与 $\mathbf{B}L, \mathbf{B}M$，将 $M$ 分支沿槽位维度翻转相减并加 $B_1$：
   $$
   P_A = \operatorname{GELU}(\mathbf{A}L - \mathbf{B}M + B_1), \qquad
   P_B = \operatorname{GELU}(\mathbf{B}L - \mathbf{A}M + B_1).
   $$
2. **单样本共享掩码 Dropout**：训练阶段对每个样本仅生成**一份**形状为 `[1, h]` 的标准缩放 Dropout 掩码 $m_P$（评估阶段 $m_P \equiv \mathbf{1}$），同时乘以 $P_A$ 与 $P_B$：
   $$
   W_A = P_A \odot m_P, \qquad W_B = P_B \odot m_P.
   $$
3. **胜负分支 Logits**：由共享权重向量 $R$ 线性读出并转为 FP32：
   $$
   z_A = W_A R, \qquad z_B = W_B R.
   $$
4. **全精度对称平局分支（FP32）**：将 $W_A, W_B$ 转为 FP32 并在零处截断得到非负胜出强度 $C_A, C_B$，结合固定差异惩罚系数 $t$ 与严格正向软加权读出 $u_{\mathrm{eff}}$ 计算平局 logit：
   $$
   C_A = \max(W_A, 0), \qquad C_B = \max(W_B, 0),
   $$
   $$
   u_{\mathrm{eff}} = s \operatorname{softplus}(u / s) = 0.01 \cdot \ln\bigl(1 + e^{100 u}\bigr) > 0 \qquad (s = 0.01),
   $$
   $$
   z_{\mathrm{tie}} = b_{\mathrm{tie}} + \bigl(C_A + C_B - t \, |C_A - C_B|\bigr) u_{\mathrm{eff}}.
   $$

最终返回 FP32 三维 logits $[z_A, z_B, z_{\mathrm{tie}}]$，经 Softmax 映射为 `(winner_model_a, winner_model_b, winner_tie)` 概率。整个分类头仅需 **3 次线性调用**，总可训练参数量为：

$$
\text{Params}_{\text{head}} = 2Dh + 3h + 1 = 2 \times 2560 \times 128 + 3 \times 128 + 1 = \mathbf{655,745}.
$$

### 2.2 理论性质与设计动机

- **代数级精确置换等变性**：当输入互换为 $(\mathbf{B}, \mathbf{A})$ 时，直接满足 $P_A(\mathbf{B}, \mathbf{A}) = P_B(\mathbf{A}, \mathbf{B})$ 与 $P_B(\mathbf{B}, \mathbf{A}) = P_A(\mathbf{A}, \mathbf{B})$。由于训练期共享同一掩码 $m_P$，输出必有 $z_A(\mathbf{B}, \mathbf{A}) = z_B(\mathbf{A}, \mathbf{B})$；而求和项 $C_A + C_B$ 与绝对差项 $|C_A - C_B|$ 均关于 $(A, B)$ 严格对称，从而保证 $z_{\mathrm{tie}}(\mathbf{B}, \mathbf{A}) \equiv z_{\mathrm{tie}}(\mathbf{A}, \mathbf{B})$。这在原理上彻底消除了顺序偏置，**无需 A/B 翻转数据增强与双方向测试平均，训练和推理算力直接节省一半**。
- **双语义平局的几何刻画**：非负通道 $C_{A,k}, C_{B,k} \ge 0$ 度量了第 $k$ 个隐藏评价维度上 A/B 的相对胜出激活。当两回答同样优秀（高激活且 $C_A \approx C_B$）或同样乏善可陈（低差异）时，$|C_{A,k} - C_{B,k}| \approx 0$，正向权重 $u_{\mathrm{eff},k} > 0$ 与 $C_A + C_B$ 共同抬高平局 logit；当一侧具有明显优势时，$|C_{A,k} - C_{B,k}|$ 增大并乘以 $-t$ 产生强负向惩罚，压低平局概率。对于完全相同的两份回答（$\mathbf{A}=\mathbf{B}$），公式自然坍缩为 $z_A=z_B$ 且 $z_{\mathrm{tie}} = b_{\mathrm{tie}} + 2C_A u_{\mathrm{eff}}$。
- **固定几何系数 $t$ 解耦斜率与尺度学习**：若同时将差异惩罚斜率 $t$ 与正向读出向量 $u_{\mathrm{eff}}$ 设为可学习参数，二者在梯度更新中容易发生尺度非凸耦合而影响校准稳定性。将 $t$ 固定为可控常量 Buffer（默认 $t = \sqrt{5}$，并在围绕黄金比例 $\phi = \frac{1+\sqrt{5}}{2}$ 的等步长网格 $\{\phi,\; \sqrt{5},\; \sqrt{5}+\phi^{-1}\}$ 上做受控验证），使梯度集中优化评价通道权重与偏置校准。

### 2.3 尺度校准初始化（`scaled_uniform_clamped_gelu_tie_v6`）

所有参数与缓冲区全部使用 FP32 存储并在训练初期保持合理方差与平滑平局先验：
- $L, M$ 独立均匀采样自 $U\bigl(-\sqrt{3/(2D)},\; \sqrt{3/(2D)}\bigr)$（标准差 $\sigma = 1/\sqrt{2D}$）；
- $R$ 采样自 $U\bigl(-0.1\sqrt{3/h},\; 0.1\sqrt{3/h}\bigr)$（标准差 $\sigma = 0.1/\sqrt{h}$），避免初始胜负 logits 幅度过大引发早期梯度饱和；
- $B_1$ 与 $b_{\mathrm{tie}}$ 均初始化为 $0$；
- 对平局读出首先采样初始有效权重 $U_0 \sim U(0.5\mu, 1.5\mu)$（其中 $\mu = 0.2/(3h)$），随后通过数值稳定的逆 Softplus 映射赋值 $u = s\bigl(x + \ln(-\operatorname{expm1}(-x))\bigr)$（$x = U_0 / s,\; s=0.01$），使前向初始 $u_{\mathrm{eff}}$ 精确等于 $U_0$。

---

## 3. 优化策略与两阶段工作流架构

代码库支持**冻结骨干纯分类头验证/构建（`SR2-Qwen3-4B`）**与**LoRA 端到端联合微调（`SR2-Qwen3-4B-lora`）**两套共享同一分类头、分词缓存与预热特征底座的工作流。其中，本压缩包 [`../results/`](../results/) 收录了第一阶段在冻结骨干上的完整 16 组受控验证实验矩阵；第二阶段用于支持全量模型导出（`--build`）并对接双 T4 离线推理提交。

### 3.1 阶段一：冻结骨干分类头训练与动态早停（`SR2-Qwen3-4B`）

由于骨干权重完全冻结，所有去重对话分支只需经过一次无梯度前向提取并持久化至 `EmbeddingCache` SQLite 存储（`external_merged` 验证范围含 `127,246` 组独立 `(prompt, response)` 分支，`lmsys33k` 全表含 `156,006` 组独立分支）。训练阶段直接读取缓存特征张量，显存峰值仅 **51.3–99.1 MiB（reserved 68–108 MiB，即 ≤ 0.11 GiB）**，单次完整验证运行纯训练耗时仅 **20–67 秒**。

在**冻结留出验证模式（`results/` 中 16 组实验）**下，训练不设固定轮次上限，采用无平滑精确验证损失驱动的动态衰减与**多级渐进耐心早停（Progressive Patience Decay）**：
- **优化配置**：`AdamW`（`lr = 1e-4`、`weight_decay = 0.01`、`max_grad_norm = 1.0`、`training_batch_size = 1024`、`dropout = 0.1`、`label_smoothing = 0.0`、`random_state = 42`）；
- **学习率调度**：`ReduceLROnPlateau(mode="min", threshold=0, min_lr=0, eps=1e-8)`，配置初始 `patience = 2`，衰减因子系统对比 `factor ∈ {0.95, 0.90, 0.85, 0.80}`；
- **渐进早停逻辑**：配置窗口 `early_stopping = 5`。每当连续 5 轮未严格降低历史最低验证损失时，若当前 `patience > 0`，则原地将 `ReduceLROnPlateau.patience` 减 `1`（依次经历 `2 -> 1 -> 0` 三阶段）并清零未改善计数，同时完整保留当前模型参数、优化器一二阶矩与学习率；当 `patience = 0` 阶段再次连续 5 轮无改善时触发终止，发布历史最低验证损失对应的 `best_epoch` 预测概率与损失。

而在全量头部构建或 LoRA 预热阶段（`Warmup`），则按预设轮数执行**区间端点精确指数衰减（`exponential_endpoint_epoch_v2`）**：设首轮学习率 $L$、末轮目标 $M$、总轮数 $N$，第 $e \in \{0, \dots, N-1\}$ 轮学习率为 $\eta_e = L \exp\bigl(-\frac{\ln L - \ln M}{N - 1} e\bigr)$。

### 3.2 阶段二：LoRA 联合微调工作流（`SR2-Qwen3-4B-lora`）

在缓存头预热的基础上，可进一步接入 PEFT 低秩适配器执行端到端联合适应，用以生成全量 `--build` 交付物（`merged/` 与 `adapter.pt`）：

| 核心配置维度 | 预设设定 | 工程与数值细节 |
| :--- | :--- | :--- |
| **LoRA 挂载目标** | `q_proj, k_proj, v_proj, o_proj, gate_proj, up_proj, down_proj` | 覆盖全部 36 层 Qwen3 注意力与前馈网络线性层 |
| **LoRA 规模** | `lora_rank = 16`, `lora_alpha = 32`, `lora_dropout = 0.1`, `bias = "none"` | 适配器可训练 **33,030,144** 参数；连同分类头总计 **33,685,889** 参数 |
| **混合精度策略** | 骨干前向/残差：`BF16`；可训练权重、梯度、AdamW 矩、头参数及输出 logits：**`FP32`** | 初始化后固定关闭 `cast_input_dtype_enabled`；分类头显式禁用 `autocast` 并显式控制 Win/Tie 精度 |
| **阶段切换重置** | 保留预热好的分类头参数与随机流状态，**进入联合训练首步前一次性清空 AdamW 动量与步数** | 避免头部预热一二阶矩干扰新接入 LoRA 适配器的初始步调 |
| **联合训练调度** | `epochs = 2`，`learning_rate = 1e-4`，余弦衰减至 `min_lr_ratio`（含 `lr_decay_delay_epochs` 可选） | 每完成一个完整优化组步进一次，包含尾部合并组 |
| **有效批大小** | `training_batch_size = 1` × `gradient_accumulation_steps = 1024`（短尾并入末组并按实际行数归一化） | 每次参数更新覆盖 1,024 行对局，梯度裁剪阈值 `1.0` |

---

## 4. 零截断工程：双阶段 Token 预算动态打包与内容寻址缓存

面对最高 **40,384 tokens**（完整外部池最高 **40,953 tokens**，`lmsys33k` 最高 **35,130 tokens**）的超长保留对局，常规静态 Batch Size 极易引发显存溢出。项目在 CPU 准备阶段构建了确定性的双阶段 Token 预算打包引擎（`TokenBudgetPacker`）：

- **微批次代价度量**：设微批次含 $n$ 条对局，A 支路最大长度 $L_A$、B 支路最大长度 $L_B$，定义独立填充总代价为 $P = n \cdot (L_A + L_B)$。
- **DP 与 Best-Fit 竞争择优**：在每个更新组内部，同时求解 **降序 Best-Fit（最小化剩余预算）** 与 **后缀动态规划（Suffix DP，最优连续切分）**，以字典序最小化 `(微批次数量, 总填充 Token 数 P)` 为唯一标准择优（完全平局保留 Best-Fit），并将单行即超预算的超长对局保留为独立单样本批、绝不截断。
- **Pass-1 基础打包与阈值自适应检查点（`threshold = 12,544`）**：比较 `(A, B)`、`(B, A)` 与 `(A+B, A, B)` 三种全局升序排序后的打包代价；运行时当微批次 $P \le 12,544$ 时关闭梯度检查点全速前向；当 $P > 12,544$ 时对 A、B 两条计算图同步启用非重入梯度检查点（`use_reentrant=False`）直达单次反向传播，并在检查点重算期保留作用域融合 SDPA 设置。
- **Pass-2 检查点单例重打包（`budget = 28,672`）**：在不跨越 `1,024` 行优化更新边界的前提下，将第一阶段遗留的需检查点单样本在更高预算 `28,672` 内重新合并打包，在 96 GB 显存安全区进一步减少超长序列小批次的 GPU 启动开销。
- **四级内容寻址与分卷原子发布**：Token 编码、无适配器分支特征、LoRA 基础批计划与已完成头部预热状态各自按完整内容与版本指纹独立缓存（通过 `CacheStorage` 管理文件锁、校验和与 $\ge 100\text{ MiB}$ 自动分卷），使多组受控超参数与数据对比可在分钟级高质量复现。
