# 03. Model Architecture, Mathematical Formulation & Training Optimization

[Back to Main Guide](../README.md) · [Previous: Data Engineering & Distribution Alignment](02_data_engineering_and_audit.md) · [Next: Experiments & Result Analysis](04_experiments_and_analysis.md)

---

## 1. Backbone Selection and Unmasked Extraction Design

### 1.1 Why `Skywork/Skywork-Reward-V2-Qwen3-4B`

Conventional approaches typically fine-tune general-purpose instruction or base LLMs from scratch for three-class preference prediction, forcing the classifier to learn both "basic semantic comprehension" and "response quality evaluation criteria" simultaneously from limited battle samples. Instead, we adopt **`Skywork/Skywork-Reward-V2-Qwen3-4B`** (pinned Hub revision `fd958fef475f323f4e6b195930e3dd918485c668`), a reward model already aligned on large-scale human preference comparisons, as our shared dual-branch backbone:
- **Strong domain prior**: Built on a 36-layer Qwen3-4B architecture with hidden dimension $D = 2560$, Grouped-Query Attention (32 Query heads, 8 KV heads, head dim 128), and native `max_position_embeddings = 40,960` tokens, its pretraining already distills accuracy, logical completeness, instruction following, and helpfulness into the final hidden space.
- **Scalar head removal and shared dual-branch encoding**: Loading `AutoModel` drops the original 1D scalar `score` linear head and retains the last hidden states. Dialogue branches A and B are encoded independently and in parallel through the same shared backbone, avoiding context doubling and quadratic attention blowup from concatenating both conversations.

### 1.2 Causal Unmasked Right-Padding and Final-Real-Token Pooling

Exploiting the mathematical property of Qwen3's **strictly causal self-attention**—where the hidden state at any real token depends solely on itself and preceding tokens, remaining completely invariant to right-side padding:
- **Fused kernels via `attention_mask=None`**: Micro-batches are right-padded independently per branch to the longest sequence in that branch, and passed to the backbone with `attention_mask=None`. This allows PyTorch SDPA to stay on fused fast paths, explicitly disabling the quadratic-memory `math` fallback via `sdpa_kernel([FLASH_ATTENTION, EFFICIENT_ATTENTION, CUDNN_ATTENTION])`, substantially boosting throughput and cutting VRAM usage on ultra-long sequences.
- **Exact final-real-token pooling**: Unpadded final token indices $L_i - 1$ are precomputed on CPU to extract $\mathbf{h}_i \in \mathbb{R}^{2560}$ directly as each branch's semantic representation.

---

## 2. SR2 v10 Exact Swap-Equivariant Classification Head (`swap_equivariant_abs_diff_v10`)

To eliminate A/B order bias structurally and model the geometric boundary of ties, we use **`SwapEquivariantAbsoluteDifferenceClassificationHead`** (architecture ID `swap_equivariant_abs_diff_v10`, feature tag `cross_projected_clamped_win_sum_diff`).

```mermaid
flowchart LR
    HA["Branch A Pooled Vector A (2560-d)"] --> Stack["Packed Linear(D, 2h)\nShared Weights L, M"]
    HB["Branch B Pooled Vector B (2560-d)"] --> Stack
    Stack --> Cross["Cross Subtraction + B1 + GELU\nP_A = GELU(AL - BM + B1)\nP_B = GELU(BL - AM + B1)"]
    Cross --> Drop["Per-Sample Shared Dropout Mask m_P\nW_A, W_B"]
    Drop --> WinHead["Shared Win Readout W_A R, W_B R\nLogits z_A, z_B (FP32)"]
    Drop --> Clamp["Cast to FP32 & Clamp at Zero\nC_A = max(W_A,0), C_B = max(W_B,0)"]
    Clamp --> TieGeom["Full-Precision Symmetric Geometry\nC_A + C_B - t * |C_A - C_B|"]
    TieGeom --> TieHead["Positive Softplus Readout u_eff + tie_bias\nLogit z_tie (FP32)"]
```

### 2.1 Mathematical Formulation and Precision Implementation

Let $\mathbf{A}, \mathbf{B} \in \mathbb{R}^{D}$ ($D = 2560$) be the pooled backbone vectors, and $h = 128$ be the head hidden width. Define learnable matrices $L, M \in \mathbb{R}^{D \times h}$, hidden bias $B_1 \in \mathbb{R}^{h}$, win readout vector $R \in \mathbb{R}^{h \times 1}$, raw tie parameter vector $u \in \mathbb{R}^{1 \times h}$, scalar bias $b_{\mathrm{tie}} \in \mathbb{R}$, and a fixed positive hyperparameter $t > 0$ (stored as an FP32 constant buffer, default $t = \sqrt{5} \approx 2.236068$).

During the head forward pass, automatic mixed precision is explicitly disabled (`torch.autocast(..., enabled=False)`): when the backbone runs in `bf16`, the win-branch inputs, `input_projection` weights, `B1`, and `R` are cast to `bfloat16` (whereas under `fp16` or `fp32` backbones, extracted features and head parameters stay in `float32`); win activations are then cast to full `float32` for the tie branch. The computation proceeds in four steps:

1. **Packed cross-projection and activation**: Stack $(\mathbf{A}, \mathbf{B})$ into `[batch, 2, D]`, compute $\mathbf{A}L, \mathbf{A}M$ and $\mathbf{B}L, \mathbf{B}M$ in **one bias-free linear call**, flip the $M$ branch along the slot dimension, subtract, and add $B_1$:
   $$
   P_A = \operatorname{GELU}(\mathbf{A}L - \mathbf{B}M + B_1), \qquad
   P_B = \operatorname{GELU}(\mathbf{B}L - \mathbf{A}M + B_1).
   $$
2. **Per-sample shared-mask dropout**: During training, generate **one** standard scaled dropout mask $m_P$ of shape `[1, h]` per sample ($m_P \equiv \mathbf{1}$ at eval) and multiply both $P_A$ and $P_B$:
   $$
   W_A = P_A \odot m_P, \qquad W_B = P_B \odot m_P.
   $$
3. **Win/loss logits**: Read out via shared weight vector $R$ and cast to FP32:
   $$
   z_A = W_A R, \qquad z_B = W_B R.
   $$
4. **Full-precision symmetric tie branch (FP32)**: Cast $W_A, W_B$ to FP32, clamp at zero to obtain non-negative win strengths $C_A, C_B$, and compute the tie logit using the fixed difference penalty $t$ and strictly positive softplus readout $u_{\mathrm{eff}}$:
   $$
   C_A = \max(W_A, 0), \qquad C_B = \max(W_B, 0),
   $$
   $$
   u_{\mathrm{eff}} = s \operatorname{softplus}(u / s) = 0.01 \cdot \ln\bigl(1 + e^{100 u}\bigr) > 0 \qquad (s = 0.01),
   $$
   $$
   z_{\mathrm{tie}} = b_{\mathrm{tie}} + \bigl(C_A + C_B - t \, |C_A - C_B|\bigr) u_{\mathrm{eff}}.
   $$

The head returns FP32 logits $[z_A, z_B, z_{\mathrm{tie}}]$, mapped via Softmax to `(winner_model_a, winner_model_b, winner_tie)` probabilities. Requiring only **3 linear calls**, the head has a total trainable parameter count of:

$$
\text{Params}_{\text{head}} = 2Dh + 3h + 1 = 2 \times 2560 \times 128 + 3 \times 128 + 1 = \mathbf{655,745}.
$$

### 2.2 Theoretical Properties and Design Motivation

- **Exact algebraic swap equivariance**: Swapping inputs to $(\mathbf{B}, \mathbf{A})$ immediately gives $P_A(\mathbf{B}, \mathbf{A}) = P_B(\mathbf{A}, \mathbf{B})$ and $P_B(\mathbf{B}, \mathbf{A}) = P_A(\mathbf{A}, \mathbf{B})$. Because training shares $m_P$, $z_A(\mathbf{B}, \mathbf{A}) = z_B(\mathbf{A}, \mathbf{B})$ holds exactly. Meanwhile, $C_A + C_B$ and $|C_A - C_B|$ are strictly symmetric in $(A, B)$, guaranteeing $z_{\mathrm{tie}}(\mathbf{B}, \mathbf{A}) \equiv z_{\mathrm{tie}}(\mathbf{A}, \mathbf{B})$. This eliminates position bias by construction, **halving training and inference compute by removing A/B flip augmentation and two-pass test-time averaging**.
- **Geometric modeling of dual-semantic ties**: Non-negative channels $C_{A,k}, C_{B,k} \ge 0$ measure relative winning activations along the $k$-th latent evaluation dimension. When both responses are equally strong (high activation, $C_A \approx C_B$) or equally weak (small difference), $|C_{A,k} - C_{B,k}| \approx 0$, so positive weights $u_{\mathrm{eff},k} > 0$ and $C_A + C_B$ elevate the tie logit. When one side clearly dominates, $|C_{A,k} - C_{B,k}|$ grows and is penalized by $-t$, suppressing the tie probability. For identical responses ($\mathbf{A}=\mathbf{B}$), the expression collapses naturally to $z_A=z_B$ and $z_{\mathrm{tie}} = b_{\mathrm{tie}} + 2C_A u_{\mathrm{eff}}$.
- **Decoupling slope and scale learning via fixed $t$**: Making both the difference penalty slope $t$ and positive readout $u_{\mathrm{eff}}$ learnable introduces non-convex scale coupling during gradient updates, hurting calibration stability. Fixing $t$ as a constant buffer (default $t = \sqrt{5}$, evaluated on an evenly spaced grid around the golden ratio $\phi = \frac{1+\sqrt{5}}{2}$: $\{\phi,\; \sqrt{5},\; \sqrt{5}+\phi^{-1}\}$) focuses optimization on channel weights and bias calibration.

### 2.3 Scale-Calibrated Initialization (`scaled_uniform_clamped_gelu_tie_v6`)

All parameters and buffers are stored in FP32 and initialized to maintain well-scaled variance and a smooth tie prior at step zero:
- $L, M$ are sampled independently from $U\bigl(-\sqrt{3/(2D)},\; \sqrt{3/(2D)}\bigr)$ ($\sigma = 1/\sqrt{2D}$);
- $R$ is sampled from $U\bigl(-0.1\sqrt{3/h},\; 0.1\sqrt{3/h}\bigr)$ ($\sigma = 0.1/\sqrt{h}$) to prevent early gradient saturation from oversized initial win logits;
- $B_1$ and $b_{\mathrm{tie}}$ are initialized to $0$;
- Tie readout initial effective weights are sampled as $U_0 \sim U(0.5\mu, 1.5\mu)$ ($\mu = 0.2/(3h)$), then mapped via numerically stable inverse softplus $u = s\bigl(x + \ln(-\operatorname{expm1}(-x))\bigr)$ ($x = U_0 / s,\; s=0.01$) so that initial $u_{\mathrm{eff}}$ equals $U_0$ exactly.

---

## 3. Optimization Strategy and Two-Stage Workflow

The codebase supports both **frozen-backbone head validation/build (`SR2-Qwen3-4B`)** and **end-to-end LoRA joint fine-tuning (`SR2-Qwen3-4B-lora`)** sharing the same head, token cache, and warmup feature base. [`../results/`](../results/) contains the complete 16-run Stage-1 frozen-backbone validation matrix, while Stage 2 supports full-data `--build` exports for dual-T4 offline submission.

### 3.1 Stage 1: Frozen-Backbone Head Training and Progressive Early Stopping (`SR2-Qwen3-4B`)

With the backbone frozen, each deduplicated conversation branch requires only a single gradient-free forward pass, persisted to `EmbeddingCache` SQLite storage (`127,246` unique `(prompt, response)` branches for `external_merged` val scope; `156,006` for `lmsys33k` full scope). Training directly reads cached feature tensors with peak VRAM of only **51.3–99.1 MiB (reserved 68–108 MiB, $\le 0.11\text{ GiB}$)** and pure training time of **20–67 seconds** per run.

In **frozen holdout validation mode (the 16 runs in `results/`)**, training uses no fixed epoch cap, driven instead by unsmoothed validation loss with **progressive patience decay**:
- **Optimizer**: `AdamW` (`lr = 1e-4`, `weight_decay = 0.01`, `max_grad_norm = 1.0`, `training_batch_size = 1024`, `dropout = 0.1`, `label_smoothing = 0.0`, `random_state = 42`);
- **LR scheduler**: `ReduceLROnPlateau(mode="min", threshold=0, min_lr=0, eps=1e-8)` with initial `patience = 2`, sweeping `factor ∈ {0.95, 0.90, 0.85, 0.80}`;
- **Progressive early stopping**: With `early_stopping = 5`, whenever validation loss fails to strictly improve for 5 consecutive epochs while `patience > 0`, `ReduceLROnPlateau.patience` is decremented by `1` in place (`2 -> 1 -> 0`) and the non-improving counter resets while preserving model weights, optimizer moments, and learning rate. Once `patience = 0` experiences another 5 consecutive non-improving epochs, training halts and emits predictions from `best_epoch`.

For full-data head builds or LoRA head warmup (`Warmup`), learning rate follows **exact endpoint exponential decay (`exponential_endpoint_epoch_v2`)**: given initial LR $L$, terminal target $M$, and total epochs $N$, epoch $e \in \{0, \dots, N-1\}$ uses $\eta_e = L \exp\bigl(-\frac{\ln L - \ln M}{N - 1} e\bigr)$.

### 3.2 Stage 2: LoRA Joint Fine-Tuning Workflow (`SR2-Qwen3-4B-lora`)

Building on the cached head warmup, PEFT low-rank adapters can be attached for end-to-end joint adaptation to produce full `--build` deliverables (`merged/` and `adapter.pt`):

| Configuration Dimension | Preset Value | Engineering & Numerical Details |
| :--- | :--- | :--- |
| **LoRA Target Modules** | `q_proj, k_proj, v_proj, o_proj, gate_proj, up_proj, down_proj` | Covers all attention and FFN linear layers across 36 Qwen3 layers |
| **LoRA Scale** | `lora_rank = 16`, `lora_alpha = 32`, `lora_dropout = 0.1`, `bias = "none"` | **33,030,144** trainable adapter parameters; **33,685,889** total with head |
| **Mixed Precision** | Backbone forward/residuals: `BF16`; trainable weights, grads, AdamW moments, head, logits: **`FP32`** | `cast_input_dtype_enabled` disabled post-init; head disables `autocast` with explicit Win/Tie precision |
| **Stage Transition Reset** | Preserves warmed-up head weights and RNG state; **clears AdamW moments and step count once before joint training** | Prevents head warmup moments from destabilizing newly attached LoRA adapters |
| **Joint Schedule** | `epochs = 2`, `learning_rate = 1e-4`, cosine decay to `min_lr_ratio` (optional `lr_decay_delay_epochs`) | Steps once per complete optimizer update group, including merged tail group |
| **Effective Batch Size** | `training_batch_size = 1` × `gradient_accumulation_steps = 1024` (short tail merged into last group, normalized by actual rows) | 1,024 battles per parameter update, gradient clipping at `1.0` |

---

## 4. Zero-Truncation Engineering: Two-Stage Token-Budget Packing & Content-Addressed Caching

Handling retained battles up to **40,384 tokens** (**40,953** in the full pool; **35,130** in `lmsys33k`) with static batch sizes would immediately trigger OOM. We implement a deterministic two-stage CPU packing engine (`TokenBudgetPacker`):

- **Micro-batch cost metric**: For a micro-batch of $n$ battles with max branch lengths $L_A$ and $L_B$, total padded token cost is $P = n \cdot (L_A + L_B)$.
- **DP vs. Best-Fit competition**: Within each update group, **descending Best-Fit** and **Suffix Dynamic Programming** are both solved, selecting the plan that lexicographically minimizes `(num_micro_batches, total_padded_tokens P)` (ties broken in favor of Best-Fit). Single battles exceeding the budget run as isolated singletons without truncation.
- **Pass-1 base packing & adaptive checkpointing (`threshold = 12,544`)**: Compares `(A, B)`, `(B, A)`, and `(A+B, A, B)` sortings. At runtime, micro-batches with $P \le 12,544$ run full-speed without checkpointing; when $P > 12,544$, non-reentrant gradient checkpointing (`use_reentrant=False`) is enabled on both A and B graphs while preserving scoped fused SDPA during recomputation.
- **Pass-2 checkpointed singleton repacking (`budget = 28,672`)**: Without crossing `1,024`-row optimizer update boundaries, leftover checkpointed singletons from Pass 1 are repacked under a `28,672` token budget, safely reducing GPU launch overhead on 96 GB VRAM.
- **Four-level content-addressed atomic caching**: Token encodings, adapter-free branch features, LoRA batch plans, and warmed-up head states are independently cached by full content and version fingerprints (`CacheStorage` with file locking, checksums, and $\ge 100\text{ MiB}$ automatic sharding), enabling minute-level reproducible ablations.
