# LLM Classification Finetuning — NTU AI6102 Team Project 报告撰写总说明

> **适用课程**：NTU AI6102: Machine Learning Methodologies & Applications（Term Paper / Kaggle Competition 报告）  
> **目标竞赛**：[Kaggle — LLM Classification Finetuning](https://www.kaggle.com/competitions/llm-classification-finetuning)（人类偏好三分类预测：A 胜 / B 胜 / 平局）  
> **打包说明**：本压缩包已整合报告所需的全部方法论说明、公式定义、数据工程规范以及 `results/` 下的 16 组受控冻结骨干验证实验产物（全部基于现行 `SR2 v10` 统一方案）。**Kaggle 线上测试集推理与排行榜截图暂缺，待完成最终提交后按模板补入。**

---

## 1. 压缩包结构与阅读导航

本压缩包采用“根目录主说明 + 结构化文档库 + 验证结果集”的三段式组织结构，解压后所有相对链接均可直接跳转：

```text
team_project_report_bundle/
├── README.md                                       # 本文件：报告总览、核心结论速查与撰写蓝图
├── docs/                                           # 结构化分模块参考文档（共 6 份）
│   ├── 01_problem_and_challenges.md                # 任务形式化定义、官方指标与五大核心挑战
│   ├── 02_data_engineering_and_audit.md            # 分组均衡划分、多源清洗合并与分布对齐选择
│   ├── 03_model_architecture_and_training.md       # Skywork-Reward-V2 骨干、SR2 v10 数学头与训练优化
│   ├── 04_experiments_and_analysis.md              # 16 组打包实验全量统计、消融结论与集成分析
│   ├── 05_kaggle_inference_and_submission_template.md  # 双 T4 离线流水线推理方案与 Kaggle 结果后补模板
│   └── 06_latex_writing_guide_and_conclusion.md    # CVPR/NeurIPS LaTeX 章节映射、公式片段与课程收获总结
└── results/                                        # 全部 16 组 SR2-Qwen3-4B 受控验证产物
    ├── SR2-Qwen3-4B-20261118-183306/               # external_merged, t=√5, factor=0.95 (val_loss=0.897444)
    ├── ...                                         # 每组均包含 config.yaml、metrics.json、validation.csv
    └── SR2-Qwen3-4B-20261119-003159/               # lmsys33k, t=√5+1/φ, factor=0.80 (val_loss=0.896191)
```

---

## 2. 核心方案与技术亮点

针对大型语言模型（LLM）对话回答的人类偏好预测任务，本项目提出了一套兼顾**奖励表征迁移**、**精确置换等变归纳偏置**、**纯 Arena 分布对齐**与**超长文本零截断工程**的端到端解决方案：

1. **奖励模型表征迁移**：放弃从通用自回归语言模型冷启动，选用已在大规模人类偏好对比上对齐的 **`Skywork/Skywork-Reward-V2-Qwen3-4B`**（36 层 Qwen3 架构，隐藏维度 $D=2560$，32 Query / 8 KV GQA，原生上下文 `40,960` tokens）作为双分支共享骨干，并严格按官方 ChatML 模板与 `<think>\n\n</think>\n\n` 默认思考块格式（`sr2-qwen3-chat-template-v1`）提取末位真实 Token 隐向量。
2. **SR2 v10 精确置换等变分类头（`swap_equivariant_abs_diff_v10`）**：将分支表征 $(A, B)$ 通过共享交叉投影 $P_A = \operatorname{GELU}(AL - BM + B_1)$ 与 $P_B = \operatorname{GELU}(BL - AM + B_1)$ 构造胜负logits；并在全精度 FP32（全局禁用 `autocast`）下直接复用同一共享 Dropout 掩码及非负截断激活 $C_A, C_B$，构建平局分支 $z_{\mathrm{tie}} = b_{\mathrm{tie}} + (C_A + C_B - t|C_A - C_B|) u_{\mathrm{eff}}$。该结构从代数层面严格满足 A/B 置换等变性，将系数 $t$ 固定为黄金比例关联几何常数以解耦斜率与通道权重，完全免除了两倍计算量的翻转数据增强与双方向测试平均。
3. **纯 Arena 多源合并与分布对齐筛选**：在永久冻结 **11,495 条**分组分层、Token 均衡的 Kaggle 验证集绝对隔离的前提下，合并清洗 Kaggle、LMSYS 33K、Arena Human 140K 与 Arena Expert 5K 得到 **220,492 行**纯 Arena 真实偏好池（剔除 102 条超 40,960 上限对话与 17 组并列冲突投票，保留唯一原向行 `is_swapped=False`）。随后通过保持竞赛 `30.95%` 平局占比的两种高纯度策略——`lmsys33k`（67,045 训练行）与 `external_merged` 英文稀有度预算精选（52,640 训练行）——避免海量现代长文本淹没竞赛基准分布。
4. **自适应优化与零截断动态打包**：基于特征缓存开展快速冻结头消融验证（使用 `ReduceLROnPlateau` + 渐进耐心衰减早停），并支持结合两阶段 Token 预算打包（Suffix DP vs Best-Fit）与自适应梯度检查点的 2 轮 LoRA 联合微调与 `--build` 权重合并导出，实现 `external_merged` 精选子集最高 **40,384 tokens**（真实合并池最高 **40,953 tokens**，`lmsys33k` 最高 **35,130 tokens**）的全程零截断处理。
5. **双 T4 离线异步流水线推理（`submit.ipynb`）**：针对 Kaggle 代码竞赛无互联网、双卡 NVIDIA T4（16 GB × 2，无原生 BF16 Tensor Core）的严苛限制，实现 Safetensors 权重流式直接切分（18/18 层转 FP16）、双阶段异步流水线重叠（`pipeline_depth=2`）、Pre-Norm 池化与 T4 专属 SDPA 内核调优，保证高吞吐离线合规提交。

```mermaid
flowchart LR
    Raw["原始真实偏好源\nKaggle + LMSYS + Arena Human + Expert"] --> Clean["清洗与硬投票合并\n同回复纠偏 / 验证Prompt隔离 / 220,492池"]
    Clean --> Select["30.95% 平局对齐选择\nlmsys33k (67,045) vs external_merged (52,640)"]
    Select --> Ser["ChatML 序列化\nsr2-qwen3-chat-template-v1\n零截断 ≤ 40,960 tokens"]
    Ser --> Frozen["阶段一：冻结 Skywork 头验证/预热\nSR2-Qwen3-4B (655,745 参数, v10)"]
    Frozen --> LoRA["阶段二（可选全量构建）：LoRA 微调\nSR2-Qwen3-4B-lora (33.69M 参数)\nDP 打包 + merged/ 导出"]
    LoRA --> Submit["Kaggle 离线推理\nsubmit.ipynb (T4 x2 FP16 流水线)"]
```

---

## 3. 核心实验结论速览（与 `results/` 严格一致）

以下全部结果均出自本压缩包 [`results/`](results/) 目录内 **16 组冻结骨干验证实验**，均在同一套 **11,495 条冻结 Kaggle 验证集**（A 胜 4,010 / B 胜 3,927 / 平局 3,558）上按单向原序（`original_only`）评测，核心指标为**多分类对数损失（Multi-class Log Loss，越低越好）**。作为无信息基线参照，均匀分布 `(1/3, 1/3, 1/3)` 的 Log Loss 为 **1.098612**，竞赛先验分布预测的 Log Loss 为 **1.097283**。

| 实验组别 | 训练数据源（行数 / 平局占比） | 固定系数 $t$ | 4 组 `factor` 验证 Loss 均值 | 最优单组运行 (`factor`) | 最优 Log Loss | 最优准确率 | 4 组预测平均集成 Log Loss |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| Group 1 | `external_merged`（52,640 / 30.95%） | $\sqrt{5} \approx 2.236068$ | 0.897336 | [`20261118-183554`](results/SR2-Qwen3-4B-20261118-183554/metrics.json) (`0.85`) | **0.897158** | 58.52% | 0.896647 |
| Group 2 | `lmsys33k`（67,045 / 30.95%） | $\sqrt{5} \approx 2.236068$ | **0.895957** | [`20261118-232414`](results/SR2-Qwen3-4B-20261118-232414/metrics.json) (`0.95`) | **0.895348** | 58.48% | **0.894941** |
| Group 3 | `lmsys33k`（67,045 / 30.95%） | $\phi \approx 1.618034$ | 0.896393 | [`20261119-002359`](results/SR2-Qwen3-4B-20261119-002359/metrics.json) (`0.95`) | **0.895890** | 58.23% | 0.895273 |
| Group 4 | `lmsys33k`（67,045 / 30.95%） | $\sqrt{5}+\phi^{-1} \approx 2.854102$ | 0.896150 | [`20261119-002945`](results/SR2-Qwen3-4B-20261119-002945/metrics.json) (`0.90`) | **0.895180** | 58.50% | 0.895246 |
| **跨数据集融合** | **`external_merged` + `lmsys33k` (8 组 @ $t=\sqrt{5}$)** | $\sqrt{5}$ | — | 概率等权平均（包内预测） | **0.893941** | **58.82%** | — |
| **全包融合** | **全部 16 组冻结头预测平均** | 混合 | — | 概率等权平均（包内全部） | **0.893515** | 58.57% | — |

关键发现（详见 [`docs/04_experiments_and_analysis.md`](docs/04_experiments_and_analysis.md)）：
- **同源配对与长文互补**：相同条件下，`lmsys33k` 凭借更高的早年模型世代重合度取得更好的单模型总损失（均值 `0.895957` vs `0.897336`）；而 `external_merged` 在多轮对话（`0.9051` vs `0.9101`）及 `>2,048` 超长文本（`0.9911` vs `1.0299`）上优势显著，两者融合后损失直降至 **`0.893941`**（准确率升至 **`58.82%`**），16 组全融合进一步降至 **`0.893515`**。
- **置换等变零偏置实证**：在未执行任何 A/B 翻转数据增强的情况下，全包 16 组模型输出 $P(A)$ 与 $P(B)$ 均值差稳定处于 `0.0007–0.0014` 区间，精确贴合验证集真实先验分布。
- **核心误差定位**：所有 16 组运行中，A 胜/B 胜单类损失均处于 `0.80–0.85`（召回率 `64%–68%`），而平局单类损失高达 `1.00–1.10`（召回率 `37%–47%`），交叉混淆主要集中于胜负与平局边界。

---

## 4. 课程报告合规核对与暂缺项清单

根据 NTU AI6102 Team Project Instructions，最终提交给助教与 **Dr. Yuan Zhou (`yuan.zhou@ntu.edu.sg`)** 的报告需满足以下要求：

| 核对项 | 课程要求 | 当前完成状态与对应位置 |
| :--- | :--- | :--- |
| **组员信息** | 包含**所有组员的姓名（Name）与学号（Matric Number）**（≤ 3 人） | **待报告首页填入**（见 [`docs/06_latex_writing_guide_and_conclusion.md`](docs/06_latex_writing_guide_and_conclusion.md)） |
| **模板格式** | 建议使用 NeurIPS / CVPR / ICML LaTeX 模板（如 CVPR 2026 Author Kit），导出 PDF | 已按标准学术报告结构备齐全部论述与 LaTeX 公式 |
| **截止时间** | **11 月 20 日（Week 14 结束）**，不可延期，无需提交源码 | 本文档包已完备覆盖无需源码即可讲清全部实现细节的内容 |
| **问题与挑战** | 用自己的语言清晰阐述问题定义与难点 | 已完整整理于 [`docs/01_problem_and_challenges.md`](docs/01_problem_and_challenges.md) |
| **解决方案与动机** | 特征工程、模型方法、设计动机与详细步骤 | 已完整整理于 [`docs/02_data_engineering_and_audit.md`](docs/02_data_engineering_and_audit.md) 与 [`docs/03_model_architecture_and_training.md`](docs/03_model_architecture_and_training.md) |
| **验证集实验** | 验证动机的消融实验 + 交叉/留出验证实验结果 | **已完备**：16 组核心实验置于 [`results/`](results/)，全量分析见 [`docs/04_experiments_and_analysis.md`](docs/04_experiments_and_analysis.md) |
| **Kaggle 线上结果** | **Leaderboard 成绩截图与提交结果分析** | **暂缺待后补**：已预留标准填空表格与截图说明于 [`docs/05_kaggle_inference_and_submission_template.md`](docs/05_kaggle_inference_and_submission_template.md) |
| **总结与收获** | 从竞赛中学习到的关键经验与反思 | 已完整整理于 [`docs/06_latex_writing_guide_and_conclusion.md`](docs/06_latex_writing_guide_and_conclusion.md) |
