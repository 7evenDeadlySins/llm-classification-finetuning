# LLM Classification Finetuning — NTU AI6102 Team Project Report Guide

> **Course**: NTU AI6102: Machine Learning Methodologies & Applications (Term Paper / Kaggle Competition Report)  
> **Target Competition**: [Kaggle — LLM Classification Finetuning](https://www.kaggle.com/competitions/llm-classification-finetuning) (Three-class human preference prediction: Model A wins / Model B wins / Tie)  
> **Bundle Overview**: This archive consolidates the methodology documentation, mathematical formulations, data engineering specifications, and 16 controlled frozen-backbone validation experiments under `results/` (all built on the unified `SR2 v10` architecture), along with the Kaggle online test results in [`docs/kaggle-results-2026-11-19.md`](docs/kaggle-results-2026-11-19.md). **Leaderboard screenshots remain to be captured and inserted per the template.**

---

## 1. Archive Structure and Navigation

This bundle follows a three-part layout consisting of a root overview, structured reference documentation, and validation artifacts. All relative links resolve directly after extraction:

```text
team_project_report_bundle/
├── README.md                                       # This file: report overview, key findings, and writing blueprint
├── docs/                                           # Structured module-by-module documentation (7 files)
│   ├── 01_problem_and_challenges.md                # Formal task definition, official metric, and five core challenges
│   ├── 02_data_engineering_and_audit.md            # Grouped balanced split, multi-source cleaning, and distribution alignment
│   ├── 03_model_architecture_and_training.md       # Skywork-Reward-V2 backbone, SR2 v10 math head, and training optimization
│   ├── 04_experiments_and_analysis.md              # Full statistics, ablations, and ensemble analysis across 16 runs
│   ├── 05_kaggle_inference_and_submission_template.md  # Dual-T4 offline pipeline inference and Kaggle results template
│   ├── 06_latex_writing_guide_and_conclusion.md    # CVPR/NeurIPS LaTeX section mapping, formulas, and lessons learned
│   └── kaggle-results-2026-11-19.md                # Kaggle test scores and configuration comparison across 5 full builds
└── results/                                        # All 16 controlled SR2-Qwen3-4B validation runs
    ├── SR2-Qwen3-4B-20261118-183306/               # external_merged, t=√5, factor=0.95 (val_loss=0.897444)
    ├── ...                                         # Each directory contains config.yaml, metrics.json, and validation.csv
    └── SR2-Qwen3-4B-20261119-003159/               # lmsys33k, t=√5+1/φ, factor=0.80 (val_loss=0.896191)
```

---

## 2. Core Solution and Technical Highlights

To predict human preferences over conversational responses from large language models (LLMs), this project introduces an end-to-end solution combining **reward representation transfer**, **exact swap-equivariant inductive bias**, **pure-Arena distribution alignment**, and **zero-truncation long-context engineering**:

1. **Reward Model Representation Transfer**: Rather than cold-starting from a general-purpose autoregressive language model, we adopt **`Skywork/Skywork-Reward-V2-Qwen3-4B`** (a 36-layer Qwen3 architecture with hidden dimension $D=2560$, 32 Query / 8 KV GQA heads, and native `40,960`-token context) already aligned on large-scale human preference comparisons as a shared dual-branch backbone. Hidden vectors are extracted from the final real token strictly following the official ChatML template and `<think>\n\n</think>\n\n` default reasoning block (`sr2-qwen3-chat-template-v1`).
2. **SR2 v10 Exact Swap-Equivariant Classification Head (`swap_equivariant_abs_diff_v10`)**: Branch representations $(A, B)$ are passed through shared cross-projections $P_A = \operatorname{GELU}(AL - BM + B_1)$ and $P_B = \operatorname{GELU}(BL - AM + B_1)$ to form win/loss logits. Under full FP32 precision (`autocast` explicitly disabled), the head reuses the same shared dropout mask and non-negative clamped activations $C_A, C_B$ to construct the tie branch $z_{\mathrm{tie}} = b_{\mathrm{tie}} + (C_A + C_B - t|C_A - C_B|) u_{\mathrm{eff}}$. This structure algebraically guarantees A/B swap equivariance and fixes $t$ to golden-ratio-related geometric constants to decouple slope and channel-weight learning, eliminating the 2x compute cost of flip augmentation and bidirectional test-time averaging.
3. **Pure-Arena Multi-Source Merging and Distribution-Aligned Selection**: Under strict isolation from the permanently frozen **11,495-row** group-stratified, token-balanced Kaggle validation set, we clean and merge Kaggle, LMSYS 33K, Arena Human 140K, and Arena Expert 5K into a **220,492-row** pure-Arena human preference pool (excluding 102 battles exceeding the 40,960-token limit and 17 tied-vote conflicts, and retaining a single canonical direction `is_swapped=False`). To prevent massive modern long-text corpora from drowning out the competition distribution, we construct two high-purity training sets anchored to the competition's `30.95%` tie rate: `lmsys33k` (67,045 training rows) and `external_merged` English rarity-budgeted selection (52,640 training rows).
4. **Adaptive Optimization and Zero-Truncation Dynamic Packing**: Rapid frozen-head ablations run on cached features using `ReduceLROnPlateau` with progressive patience decay early stopping. The pipeline also supports 2-epoch LoRA joint fine-tuning and `--build` weight merging via two-stage token-budget packing (Suffix DP vs. Best-Fit) and adaptive gradient checkpointing, achieving zero truncation up to **40,384 tokens** in the `external_merged` subset (**40,953 tokens** in the full pool, and **35,130 tokens** in `lmsys33k`).
5. **Dual-T4 Offline Asynchronous Pipeline Inference (`submit.ipynb`)**: Designed for Kaggle's offline code-competition environment with dual NVIDIA T4 GPUs (16 GB × 2, lacking native BF16 Tensor Cores), the submission notebook performs streaming Safetensors sharded loading (18/18 layers cast to FP16), two-stage asynchronous pipeline overlap (`pipeline_depth=2`), Pre-Norm pooling, and T4-tuned SDPA kernels for high-throughput compliant inference.

```mermaid
flowchart LR
    Raw["Raw Human Preference Sources\nKaggle + LMSYS + Arena Human + Expert"] --> Clean["Cleaning & Hard-Vote Deduplication\nIdentical-Response Fix / Val Isolation / 220,492 Pool"]
    Clean --> Select["30.95% Tie-Aligned Selection\nlmsys33k (67,045) vs external_merged (52,640)"]
    Select --> Ser["ChatML Serialization\nsr2-qwen3-chat-template-v1\nZero Truncation <= 40,960 tokens"]
    Ser --> Frozen["Stage 1: Frozen Skywork Head Validation / Warmup\nSR2-Qwen3-4B (655,745 params, v10)"]
    Frozen --> LoRA["Stage 2 (Optional Full Build): LoRA Fine-Tuning\nSR2-Qwen3-4B-lora (33.69M params)\nDP Packing + merged/ Export"]
    LoRA --> Submit["Kaggle Offline Inference\nsubmit.ipynb (T4 x2 FP16 Pipeline)"]
```

---

## 3. Summary of Key Experimental Findings (Consistent with `results/`)

All validation results below come from the **16 frozen-backbone validation experiments** in [`results/`](results/), evaluated on the identical **11,495-row frozen Kaggle validation set** (A wins: 4,010 / B wins: 3,927 / Tie: 3,558) using single-direction inference (`original_only`). The primary metric is **Multi-class Log Loss (lower is better)**. As uninformative baselines, a uniform distribution `(1/3, 1/3, 1/3)` yields a Log Loss of **1.098612**, and the competition prior yields **1.097283**.

| Experiment Group | Training Source (Rows / Tie Rate) | Fixed $t$ | Mean Val Loss (4 `factor`s) | Best Single Run (`factor`) | Best Log Loss | Best Accuracy | 4-Run Ensemble Log Loss |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| Group 1 | `external_merged` (52,640 / 30.95%) | $\sqrt{5} \approx 2.236068$ | 0.897336 | [`20261118-183554`](results/SR2-Qwen3-4B-20261118-183554/metrics.json) (`0.85`) | **0.897158** | 58.52% | 0.896647 |
| Group 2 | `lmsys33k` (67,045 / 30.95%) | $\sqrt{5} \approx 2.236068$ | **0.895957** | [`20261118-232414`](results/SR2-Qwen3-4B-20261118-232414/metrics.json) (`0.95`) | **0.895348** | 58.48% | **0.894941** |
| Group 3 | `lmsys33k` (67,045 / 30.95%) | $\phi \approx 1.618034$ | 0.896393 | [`20261119-002359`](results/SR2-Qwen3-4B-20261119-002359/metrics.json) (`0.95`) | **0.895890** | 58.23% | 0.895273 |
| Group 4 | `lmsys33k` (67,045 / 30.95%) | $\sqrt{5}+\phi^{-1} \approx 2.854102$ | 0.896150 | [`20261119-002945`](results/SR2-Qwen3-4B-20261119-002945/metrics.json) (`0.90`) | **0.895180** | 58.50% | 0.895246 |
| **Cross-Dataset Ensemble** | **`external_merged` + `lmsys33k` (8 runs @ $t=\sqrt{5}$)** | $\sqrt{5}$ | — | Equal-weight probability avg | **0.893941** | **58.82%** | — |
| **Full-Bundle Ensemble** | **All 16 frozen-head predictions averaged** | Mixed | — | Equal-weight probability avg | **0.893515** | 58.57% | — |

Key takeaways (detailed in [`docs/04_experiments_and_analysis.md`](docs/04_experiments_and_analysis.md)):
- **Epoch-Matched Pairing and Long-Context Complementarity**: Under identical settings, `lmsys33k` achieves lower single-model overall loss (`0.895957` vs. `0.897336` mean) due to higher overlap with early model generations, whereas `external_merged` excels on multi-turn dialogues (`0.9051` vs. `0.9101`) and long contexts `>2,048` tokens (`0.9911` vs. `1.0299`). Combining both at $t=\sqrt{5}$ drops validation loss to **`0.893941`** (**`58.82%`** accuracy), and averaging all 16 runs reaches **`0.893515`**.
- **Empirical Zero Position Bias**: Without any A/B flip augmentation, the difference between mean predicted $P(A)$ and $P(B)$ across all 16 runs stays within `0.0007–0.0014`, closely matching the true validation prior.
- **Primary Error Concentration**: Across all 16 runs, per-class Log Loss for Model A and Model B wins stays in `0.80–0.85` (`64%–68%` recall), while the Tie class incurs `1.00–1.10` Log Loss (`37%–47%` recall), confirming that most confusion occurs along the win/tie boundary.

In addition, **5 full-build Kaggle submissions** (`78,540` rows) are documented in [`docs/kaggle-results-2026-11-19.md`](docs/kaggle-results-2026-11-19.md), where LoRA joint fine-tuning (`SR2-Qwen3-4B-lora`) improves Kaggle test scores by roughly `0.03` over frozen-head builds (`0.88924` / `0.88950` vs. `0.91887` / `0.92105`).

---

## 4. Course Report Compliance Checklist

Per the NTU AI6102 Team Project Instructions, the final report submitted to the TA and **Dr. Yuan Zhou (`yuan.zhou@ntu.edu.sg`)** must satisfy the following requirements:

| Checklist Item | Course Requirement | Status & Location |
| :--- | :--- | :--- |
| **Team Information** | Full **Names and Matriculation Numbers** of all members ($\le 3$) | **To be filled on title page** (see [`docs/06_latex_writing_guide_and_conclusion.md`](docs/06_latex_writing_guide_and_conclusion.md)) |
| **Template Format** | NeurIPS / CVPR / ICML LaTeX template (e.g., CVPR 2026 Author Kit), exported as PDF | All arguments and LaTeX equations prepared in academic structure |
| **Deadline** | **November 20 (End of Week 14)**, strict deadline, no source code submission required | This bundle covers all implementation details without requiring source code |
| **Problem & Challenges** | Clear problem statement and challenges in your own words | Complete in [`docs/01_problem_and_challenges.md`](docs/01_problem_and_challenges.md) |
| **Solution & Motivation** | Feature engineering, modeling approach, design motivation, and detailed steps | Complete in [`docs/02_data_engineering_and_audit.md`](docs/02_data_engineering_and_audit.md) & [`docs/03_model_architecture_and_training.md`](docs/03_model_architecture_and_training.md) |
| **Validation Experiments** | Motivation verification ablations + cross/holdout validation results | **Complete**: 16 core runs in [`results/`](results/), full analysis in [`docs/04_experiments_and_analysis.md`](docs/04_experiments_and_analysis.md) |
| **Kaggle Online Results** | **Leaderboard screenshot & test submission analysis** | **Scores recorded** in [`docs/kaggle-results-2026-11-19.md`](docs/kaggle-results-2026-11-19.md); screenshot template in [`docs/05_kaggle_inference_and_submission_template.md`](docs/05_kaggle_inference_and_submission_template.md) |
| **Conclusion** | Key lessons learned from the competition | Complete in [`docs/06_latex_writing_guide_and_conclusion.md`](docs/06_latex_writing_guide_and_conclusion.md) |
